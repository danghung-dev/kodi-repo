"""YanHH3D provider. Selectors come from the pages captured in tests/fixtures."""

import re
import urllib.parse

from .. import htmldom
from ..errors import ParseError
from ..models import CatalogItem, Episode, Page, PlaybackOption, Section, TitleDetails
from .base import Provider

CATALOG_TTL = 300
DETAIL_TTL = 3600
GENRES_TTL = 86400

# Verified servers: ``tiktik`` (Vietsub) and ``tiktm`` (Thuyết minh), both 1080 V1
# on the same Streamfree host. Other types the page lists stay hidden unless the
# user opts in, because their playback is unverified.
DEFAULT_TYPES = frozenset(("tiktik", "tiktm"))

_SV_RE = re.compile(r'\b(?:let|const|var)\s+sv\s*=\s*([\'"]?)(\d+)\1\s*;')
_ENDPOINT_RE = re.compile(r'\burl\s*:\s*([\'"])([^\'"]*/player/player\.php)\1')
_SCRIPT_RE = re.compile(r"<script\b[^>]*>(.*?)</script\s*>", re.S | re.I)


def _norm(url):
    parts = urllib.parse.urlsplit(url)
    return urllib.parse.urlunsplit(
        (parts.scheme, parts.netloc.lower(), parts.path.rstrip("/"), parts.query, "")
    )


def _language_group(label):
    lowered = label.lower()
    if lowered.startswith("vietsub"):
        return "Vietsub"
    if lowered.startswith("thuyết minh"):
        return "Thuyết minh"
    return "Khác"


class YanHH3D(Provider):
    provider_id = "yanhh3d"
    name = "YanHH3D"
    DEFAULT_BASE_URL = "https://yanhh3d.ee"

    # ----- navigation -------------------------------------------------

    def get_sections(self):
        base = self.base_url
        return [
            Section("latest", "Mới cập nhật", "list", base + "/yanhh3d-moi-cap-nhat"),
            Section("search", "Tìm kiếm", "search"),
            Section("genres", "Thể loại", "genres"),
            Section(
                "completed",
                "Hoạt hình đã hoàn thành",
                "list",
                base + "/yanhh3d-hoan-thanh",
            ),
            Section("top", "Top xem nhiều", "list", base + "/top-yanhh3d-xem-nhieu"),
        ]

    def list_titles(self, url):
        html = self._get(url, CATALOG_TTL)
        return self.parse_list(html, url)

    def search(self, query):
        url = "%s/?%s" % (self.base_url, urllib.parse.urlencode({"s": query}))
        return self.list_titles(url)

    def get_genres(self):
        html = self._get(self.base_url + "/", GENRES_TTL)
        return self.parse_genres(html)

    # ----- title details ----------------------------------------------

    def get_title(self, url):
        return self.parse_title(self._get(url, DETAIL_TTL), url)

    # ----- playback options -------------------------------------------

    def get_playback_options(self, episode_url):
        html = self._get(episode_url, 0)
        return self.parse_options(html, episode_url)

    def get_embed_url(self, option):
        html = self.http.get_text(
            option.source["player_url"],
            referer=option.source["referer"],
            allowed_hosts={self.host},
        )
        return self.parse_embed(html, option.source["player_url"])

    # ----- fetch helper -----------------------------------------------

    def _get(self, url, ttl):
        return self.http.get_text(
            url, referer=self.base_url + "/", allowed_hosts={self.host}, cache_ttl=ttl
        )

    def _absolute(self, href, base):
        url = urllib.parse.urldefrag(urllib.parse.urljoin(base, href.strip()))[0]
        return url

    # ----- parsers (pure; exercised by tests/test_yanhh3d.py) ---------

    def parse_list(self, html, page_url):
        doc = htmldom.parse(html)
        containers = doc.select(".film_list-wrap")  # first one with cards is the main list
        items, seen = [], set()
        for container in containers:
            for card in container.select(".flw-item"):
                item = self._parse_card(card, page_url)
                if item and item.url not in seen:
                    seen.add(item.url)
                    items.append(item)
            if items:
                break
        heading = doc.select_one("#main-content .cat-heading")
        nxt = doc.select_one("ul.pagination a.next")
        next_url = (
            self._absolute(nxt.get("href"), page_url)
            if nxt and nxt.get("href")
            else None
        )
        if next_url and not self.owns_url(next_url):
            next_url = None
        return Page(items, next_url, heading.text() if heading else "")

    def _parse_card(self, card, page_url):
        link = card.select_one("a.film-poster-ahref") or card.select_one(".film-name a")
        if not link or not link.get("href"):
            return None
        url = self._absolute(link.get("href"), page_url)
        if not self.owns_url(url):
            return None
        name_link = card.select_one(".film-name a")
        title = (name_link.text() if name_link else "") or link.get("title", "").strip()
        if not title:
            return None
        image = card.select_one("img.film-poster-img")
        poster = (
            self._absolute(image.get("src"), page_url)
            if image and image.get("src")
            else ""
        )
        label = " · ".join(
            filter(
                None,
                [
                    card.select_one(".tick-rate").text()
                    if card.select_one(".tick-rate")
                    else "",
                    card.select_one(".tick-item").text()
                    if card.select_one(".tick-item")
                    else "",
                ],
            )
        )
        return CatalogItem(
            self.provider_id,
            urllib.parse.urlsplit(url).path.strip("/").rsplit("/", 1)[-1],
            url,
            title,
            "",
            poster,
            label,
        )

    def parse_genres(self, html):
        doc = htmldom.parse(html)
        menu = doc.select("li.menu-item-has-children > ul.dropdown-menu > li > a")
        genres, seen = [], set()
        for link in menu:
            if "menu-item-object-category" not in link.parent.classes:
                continue
            url = self._absolute(link.get("href", ""), self.base_url + "/")
            if self.owns_url(url) and url not in seen:
                seen.add(url)
                genres.append(
                    Section(
                        urllib.parse.urlsplit(url).path.strip("/"),
                        link.text(),
                        "list",
                        url,
                    )
                )
        if not genres:
            raise ParseError(
                "Không đọc được danh sách thể loại; giao diện website có thể đã đổi."
            )
        return genres

    def parse_title(self, html, page_url):
        doc = htmldom.parse(html)
        heading = doc.select_one(".anisc-detail h1.film-name")
        if not heading:
            raise ParseError(
                "Không đọc được trang phim; giao diện website có thể đã đổi."
            )
        original = doc.select_one(".anisc-detail h2.film-name-real")
        image = doc.select_one(".anisc-poster img.film-poster-img")
        slug = urllib.parse.urlsplit(page_url).path.strip("/").rsplit("/", 1)[-1]
        item = CatalogItem(
            self.provider_id,
            slug,
            page_url,
            heading.text(),
            original.text() if original else "",
            self._absolute(image.get("src"), page_url)
            if image and image.get("src")
            else "",
        )
        plot = doc.select_one(".film-description .text")
        info = {}
        for row in doc.select(".anisc-info .item"):
            head = row.select_one(".item-head")
            if head:
                info[head.text().rstrip(":").strip().lower()] = row
        name = lambda key: (
            info[key].select_one(".name").text()
            if key in info and info[key].select_one(".name")
            else ""
        )
        genres = [a.text() for a in doc.select(".anisc-info .item-cate a")]
        episodes, seen = [], set()
        for link in doc.select(".ep-range a.ep-item"):
            href = link.get("href")
            if not href:
                continue
            url = self._absolute(href, page_url)
            if url in seen or not self.owns_url(url):
                continue
            seen.add(url)
            episodes.append(
                Episode(
                    self.provider_id,
                    link.get("data-ep") or url.rsplit("/", 1)[-1],
                    link.text() or link.get("title", ""),
                    url,
                    "",
                    len(episodes),
                    link.get("data-post-id", ""),
                )
            )
        related = [
            (
                a.select_one(".title").text()
                if a.select_one(".title")
                else a.get("title", "").strip(),
                self._absolute(a.get("href", ""), page_url),
            )
            for a in doc.select(".os-list a.os-item")
            if "active" not in a.classes
        ]
        return TitleDetails(
            item,
            plot.text() if plot else "",
            genres,
            name("trạng thái"),
            name("thời lượng"),
            name("lịch chiếu"),
            episodes,
            [r for r in related if self.owns_url(r[1])],
        )

    def parse_options(self, html, watch_url):
        doc = htmldom.parse(html)
        watch = _norm(watch_url)
        episode = next(
            (
                link
                for link in doc.select("a.ep-item")
                if link.get("data-post-id")
                and link.get("data-ep")
                and link.get("href")
                and _norm(self._absolute(link.get("href"), watch_url)) == watch
            ),
            None,
        )
        if not episode:
            raise ParseError("Trang tập không có data-post-id/data-ep khớp URL tập.")
        player_script = next(
            (
                s
                for s in _SCRIPT_RE.findall(html)
                if re.search(r"function\s+loadPlayer\s*\(", s)
                and "dox_ajax_player" in s
            ),
            None,
        )
        endpoint = (
            _ENDPOINT_RE.search(player_script).group(2)
            if player_script and _ENDPOINT_RE.search(player_script)
            else None
        )
        if not endpoint:
            raise ParseError(
                "Không tìm thấy endpoint loadPlayer; cần cập nhật provider."
            )
        player_url = self._absolute(endpoint, watch_url)
        if not self.owns_url(player_url):
            raise ParseError("Endpoint player không cùng máy chủ với website.")
        # sv comes from the link, else from the page's initial loadPlayer call.
        sv = episode.get("data-sv") or (
            _SV_RE.search(player_script).group(2)
            if _SV_RE.search(player_script)
            else ""
        )
        if not re.fullmatch(r"\d+", sv or ""):
            raise ParseError("Không xác định được nhóm ngôn ngữ (sv) của trang tập.")
        options, seen = [], set()
        for button in doc.select(".btn3dsv"):
            kind = button.get("data-type")
            if not kind or kind in seen:
                continue
            seen.add(kind)
            label = button.text()
            query = urllib.parse.urlencode(
                [
                    ("action", "dox_ajax_player"),
                    ("post_id", episode.get("data-post-id")),
                    ("chapter_st", episode.get("data-ep")),
                    ("sv", sv),
                    ("type", kind),
                ]
            )
            options.append(
                PlaybackOption(
                    self.provider_id,
                    kind,
                    label,
                    _language_group(label),
                    kind in DEFAULT_TYPES,
                    {"player_url": "%s?%s" % (player_url, query), "referer": watch_url},
                )
            )
        if not options:
            raise ParseError("Trang tập không có nút server.")
        return options

    def parse_embed(self, html, base_url):
        frame = htmldom.parse(html).select_one("iframe[src]")
        if not frame:
            raise ParseError("Phản hồi player không có iframe.")
        url = self._absolute(frame.get("src"), base_url)
        parts = urllib.parse.urlsplit(url)
        if parts.scheme != "https" or parts.username or parts.password:
            raise ParseError("Iframe player không dùng HTTPS.")
        return url
