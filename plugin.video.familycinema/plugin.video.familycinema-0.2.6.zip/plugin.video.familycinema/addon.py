"""Plugin entry point: plugin://plugin.video.familycinema/?action=..."""
import os
import sys

from resources.lib import kodi_ui
from resources.lib.cache import Cache
from resources.lib.http_client import HttpClient
from resources.lib.router import Router


def main():
    handle = int(sys.argv[1])
    query = sys.argv[2][1:] if len(sys.argv) > 2 else ''
    settings = kodi_ui.load_settings()
    cache = Cache(os.path.join(kodi_ui.profile_dir(), 'cache') if settings.cache_enabled else None)
    router = Router(kodi_ui.KodiUI(handle), HttpClient(cache=cache), settings)
    router.dispatch(query)


if __name__ == '__main__':
    main()
