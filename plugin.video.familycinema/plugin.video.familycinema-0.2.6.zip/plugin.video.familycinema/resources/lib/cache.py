"""Tiny TTL cache for page text. Never used for media URLs (they expire)."""
import hashlib
import json
import os
import time


class Cache:
    def __init__(self, directory=None, clock=time.time):
        self._dir = directory
        self._clock = clock
        self._memory = {}
        if directory:
            try:
                os.makedirs(directory, exist_ok=True)
            except OSError:
                self._dir = None

    def _path(self, key):
        return os.path.join(self._dir, hashlib.sha1(key.encode('utf-8')).hexdigest() + '.json')

    def get(self, key, ttl):
        if ttl <= 0:
            return None
        now = self._clock()
        entry = self._memory.get(key)
        if entry is None and self._dir:
            try:
                with open(self._path(key), encoding='utf-8') as handle:
                    entry = json.load(handle)
            except (OSError, ValueError):
                entry = None
        if entry and now - entry['t'] <= ttl:
            self._memory[key] = entry
            return entry['body']
        return None

    def put(self, key, body):
        entry = {'t': self._clock(), 'body': body}
        self._memory[key] = entry
        if self._dir:
            try:
                with open(self._path(key), 'w', encoding='utf-8') as handle:
                    json.dump(entry, handle)
            except OSError:
                pass

    def clear(self):
        self._memory.clear()
        if self._dir:
            for name in os.listdir(self._dir):
                if name.endswith('.json'):
                    try:
                        os.remove(os.path.join(self._dir, name))
                    except OSError:
                        pass
