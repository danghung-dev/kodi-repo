"""Exception types shared by providers, resolvers and the Kodi layer."""


class FamilyCinemaError(Exception):
    """Base class; ``str(error)`` is safe to show to the user."""


class NetworkError(FamilyCinemaError):
    """Request failed (timeout, DNS, HTTP status, redirect to a foreign host)."""


class ParseError(FamilyCinemaError):
    """The page no longer matches the structure the parser expects."""


class RouteError(FamilyCinemaError):
    """A plugin URL referenced an unknown provider, action or foreign host."""


class ResolverUnavailable(FamilyCinemaError):
    """No resolver can turn this playback option into a media stream."""
