"""Small tolerant HTML tree with a CSS selector subset, built on the stdlib.

Supported selectors: tag, ``.class``, ``#id``, ``[attr]``, ``[attr=value]``,
``[attr~=value]``, compound selectors, descendant (space) and child (``>``)
combinators, and comma-separated groups. Enough for provider parsers without
adding a Kodi dependency such as BeautifulSoup.
"""

import re
from html.parser import HTMLParser

VOID = frozenset(
    (
        "area",
        "base",
        "br",
        "col",
        "embed",
        "hr",
        "img",
        "input",
        "link",
        "meta",
        "param",
        "source",
        "track",
        "wbr",
    )
)
SKIP_CONTENT = frozenset(("script", "style", "svg", "noscript", "template"))


class Node:
    __slots__ = ("tag", "attrs", "children", "parent", "data")

    def __init__(self, tag, attrs=None, parent=None, data=None):
        self.tag = tag
        self.attrs = attrs or {}
        self.children = []
        self.parent = parent
        self.data = data  # text for text nodes (tag is None)

    def get(self, name, default=None):
        return self.attrs.get(name, default)

    @property
    def classes(self):
        return self.attrs.get("class", "").split()

    def text(self):
        """Visible text with whitespace collapsed."""
        parts = []
        self._collect(parts)
        return re.sub(r"\s+", " ", "".join(parts)).strip()

    def _collect(self, parts):
        for child in self.children:
            if child.tag is None:
                parts.append(child.data)
            else:
                child._collect(parts)

    def iter(self):
        for child in self.children:
            if child.tag is not None:
                yield child
                yield from child.iter()

    def ancestors(self):
        node = self.parent
        while node is not None:
            yield node
            node = node.parent

    def select(self, selector):
        return select(self, selector)

    def select_one(self, selector):
        return next(iter(select(self, selector)), None)


class _Builder(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = Node("#document")
        self.stack = [self.root]
        self._skip = None

    def handle_starttag(self, tag, attrs):
        if self._skip:
            if tag == self._skip:
                self._depth += 1
            return
        node = Node(
            tag, {k: (v if v is not None else "") for k, v in attrs}, self.stack[-1]
        )
        self.stack[-1].children.append(node)
        if tag in VOID:
            return
        if tag in SKIP_CONTENT:
            self._skip, self._depth = tag, 1
            return
        self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        if self._skip:
            return
        node = Node(
            tag, {k: (v if v is not None else "") for k, v in attrs}, self.stack[-1]
        )
        self.stack[-1].children.append(node)

    def handle_endtag(self, tag):
        if self._skip:
            if tag == self._skip:
                self._depth -= 1
                if self._depth == 0:
                    self._skip = None
            return
        if tag in VOID:
            return
        for index in range(len(self.stack) - 1, 0, -1):
            if self.stack[index].tag == tag:
                del self.stack[index:]
                return

    def handle_data(self, data):
        if self._skip or not data:
            return
        self.stack[-1].children.append(Node(None, parent=self.stack[-1], data=data))


def parse(html):
    builder = _Builder()
    builder.feed(html)
    builder.close()
    return builder.root


_SIMPLE = re.compile(
    r"(?P<tag>[a-zA-Z][\w-]*|\*)?"
    r"(?P<rest>(?:[.#][\w-]+|\[[^\]]+\])*)$"
)
_PART = re.compile(
    r'([.#])([\w-]+)|\[\s*([\w:-]+)\s*(?:([~^$*]?=)\s*(?:"([^"]*)"|\'([^\']*)\'|([^\]\s]*)))?\s*\]'
)


def _compile_compound(text):
    match = _SIMPLE.match(text)
    if not match:
        raise ValueError("Unsupported selector: %r" % text)
    tag = match.group("tag")
    tests = []
    for part in _PART.finditer(match.group("rest")):
        kind, ident, attr, op, v1, v2, v3 = part.groups()
        if kind == ".":
            tests.append(lambda n, c=ident: c in n.classes)
        elif kind == "#":
            tests.append(lambda n, i=ident: n.attrs.get("id") == i)
        else:
            value = v1 if v1 is not None else v2 if v2 is not None else v3
            tests.append(_attr_test(attr, op, value))

    def match_node(node):
        if tag and tag != "*" and node.tag != tag.lower():
            return False
        return all(test(node) for test in tests)

    return match_node


def _attr_test(attr, op, value):
    if op is None:
        return lambda n: attr in n.attrs
    if op == "=":
        return lambda n: n.attrs.get(attr) == value
    if op == "~=":
        return lambda n: value in n.attrs.get(attr, "").split()
    if op == "^=":
        return lambda n: n.attrs.get(attr, "").startswith(value)
    if op == "$=":
        return lambda n: n.attrs.get(attr, "").endswith(value)
    return lambda n: value in n.attrs.get(attr, "")


def _compile_chain(selector):
    tokens = re.sub(r"\s*>\s*", " > ", selector.strip()).split()
    chain = []  # (combinator, matcher)
    combinator = " "
    for token in tokens:
        if token == ">":
            combinator = ">"
            continue
        chain.append((combinator, _compile_compound(token)))
        combinator = " "
    if not chain:
        raise ValueError("Empty selector")
    return chain


def _matches_chain(node, chain, scope):
    """Match right-to-left; ``scope`` bounds ancestor lookups."""
    index = len(chain) - 1
    if not chain[index][1](node):
        return False
    return _match_up(node, chain, index, scope)


def _match_up(node, chain, index, scope):
    if index == 0:
        return True
    combinator = chain[index][0]
    matcher = chain[index - 1][1]
    parent = node.parent
    if combinator == ">":
        if parent is None or parent is scope.parent or not matcher(parent):
            return False
        return _match_up(parent, chain, index - 1, scope)
    while parent is not None and parent is not scope.parent:
        if matcher(parent) and _match_up(parent, chain, index - 1, scope):
            return True
        parent = parent.parent
    return False


def select(root, selector):
    chains = [_compile_chain(part) for part in selector.split(",") if part.strip()]
    return [
        node
        for node in root.iter()
        if any(_matches_chain(node, chain, root) for chain in chains)
    ]
