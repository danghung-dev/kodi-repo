"""HTTP for providers: timeout, cookies, bounded retry, host allow-list, cache."""
import gzip
import http.cookiejar
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib

from .cache import Cache
from .errors import NetworkError

USER_AGENT = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36')
RETRY_STATUS = frozenset((500, 502, 503, 504))
MAX_RESPONSE = 32 * 1024 * 1024


class _Response:
    def __init__(self, status, headers, body, url):
        self.status, self.headers, self.body, self.url = status, headers, body, url


def _default_transport(cookies):
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookies))

    def send(request, timeout):
        try:
            with opener.open(request, timeout=timeout) as response:
                return _Response(response.status, response.headers, response.read(MAX_RESPONSE + 1), response.geturl())
        except urllib.error.HTTPError as error:
            return _Response(error.code, error.headers, error.read(), error.geturl())
    return send


class HttpClient:
    def __init__(self, timeout=20, retries=2, cache=None, transport=None, sleep=time.sleep,
                 user_agent=USER_AGENT):
        self.timeout = timeout
        self.retries = max(0, retries)
        self.cache = cache or Cache()
        self._cookies = http.cookiejar.CookieJar()
        self._send = transport or _default_transport(self._cookies)
        self._sleep = sleep
        self.user_agent = user_agent

    def get_text(self, url, referer=None, allowed_hosts=None, cache_ttl=0):
        """GET ``url`` as text. Raises NetworkError; only https URLs are allowed.

        ``allowed_hosts`` is enforced on the request URL and on the final URL
        after redirects, so a redirect cannot move the add-on to another site.
        """
        return self._get(url, referer, allowed_hosts, cache_ttl, binary=False)

    def get_bytes(self, url, referer=None, allowed_hosts=None):
        """GET media bytes without decoding text or caching expiring URLs."""
        return self._get(url, referer, allowed_hosts, 0, binary=True)

    def _get(self, url, referer, allowed_hosts, cache_ttl, binary):
        self._check(url, allowed_hosts)
        cached = self.cache.get(url, cache_ttl)
        if cached is not None:
            return cached
        headers = {'User-Agent': self.user_agent, 'Accept-Encoding': 'gzip, deflate',
                   'Accept-Language': 'vi,en;q=0.8'}
        if referer:
            headers['Referer'] = referer
        request = urllib.request.Request(url, headers=headers)
        last = None
        for attempt in range(self.retries + 1):
            try:
                response = self._send(request, self.timeout)
            except (urllib.error.URLError, OSError, ValueError) as error:
                last = NetworkError('Không kết nối được tới %s (%s)' % (urllib.parse.urlsplit(url).hostname, error))
            else:
                self._check(response.url, allowed_hosts)
                if response.status == 200:
                    if len(response.body) > MAX_RESPONSE:
                        raise NetworkError('Response vượt giới hạn kích thước')
                    text = self._bytes(response) if binary else self._decode(response)
                    if cache_ttl > 0:
                        self.cache.put(url, text)
                    return text
                last = NetworkError('HTTP %s từ %s' % (response.status, urllib.parse.urlsplit(url).hostname))
                if response.status not in RETRY_STATUS:
                    raise last
            if attempt < self.retries:
                self._sleep(0.5 * (attempt + 1))
        raise last

    @staticmethod
    def _check(url, allowed_hosts):
        parts = urllib.parse.urlsplit(url)
        if parts.scheme != 'https' or parts.username or parts.password:
            raise NetworkError('Chỉ cho phép HTTPS không kèm tài khoản: %s' % parts.hostname)
        host = (parts.hostname or '').lower()
        permitted = allowed_hosts(host) if callable(allowed_hosts) else allowed_hosts is None or host in allowed_hosts
        if not permitted:
            raise NetworkError('Máy chủ không nằm trong danh sách cho phép: %s' % parts.hostname)

    @staticmethod
    def _bytes(response):
        body = response.body
        encoding = (response.headers.get('Content-Encoding') or '').lower()
        try:
            if encoding == 'gzip':
                body = gzip.decompress(body)
            elif encoding == 'deflate':
                body = zlib.decompress(body)
        except (OSError, zlib.error) as error:
            raise NetworkError('Dữ liệu nén lỗi: %s' % error)
        if len(body) > MAX_RESPONSE:
            raise NetworkError('Response vượt giới hạn kích thước')
        return body

    @staticmethod
    def _decode(response):
        body = HttpClient._bytes(response)
        charset = response.headers.get_content_charset() if hasattr(response.headers, 'get_content_charset') else None
        return body.decode(charset or 'utf-8', errors='replace')
