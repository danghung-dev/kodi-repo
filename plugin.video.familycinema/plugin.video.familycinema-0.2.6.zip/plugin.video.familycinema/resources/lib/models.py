"""Provider-independent data contract. Identity always includes the provider."""
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


@dataclass(frozen=True)
class Section:
    """A browsable entry of a provider's top-level menu."""
    section_id: str
    title: str
    kind: str  # 'list' (paged titles) | 'search' | 'genres'
    url: str = ''


@dataclass(frozen=True)
class CatalogItem:
    provider: str
    item_id: str
    url: str
    title: str
    original_title: str = ''
    poster: str = ''
    label: str = ''


@dataclass(frozen=True)
class Page:
    items: List[CatalogItem]
    next_url: Optional[str] = None
    title: str = ''


@dataclass(frozen=True)
class Episode:
    provider: str
    episode_id: str  # verbatim source id, e.g. 'tap-207-rv04'
    label: str
    url: str
    group: str = ''  # language group when the source lists episodes per group
    order: int = 0  # position in the source list
    post_id: str = ''


@dataclass(frozen=True)
class TitleDetails:
    item: CatalogItem
    plot: str = ''
    genres: List[str] = field(default_factory=list)
    status: str = ''
    duration: str = ''
    schedule: str = ''
    episodes: List[Episode] = field(default_factory=list)
    related: List[Tuple[str, str]] = field(default_factory=list)  # (title, url)


@dataclass(frozen=True)
class PlaybackOption:
    """One server/quality choice exactly as the source advertises it."""
    provider: str
    option_id: str  # source ``data-type``
    label: str
    group: str  # language group derived from the source label
    default_enabled: bool  # shown without the 'show all servers' setting
    source: Dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class ResolvedStream:
    url: str
    headers: Dict[str, str] = field(default_factory=dict)
    mime: str = ''
    protocol: str = ''  # 'hls' | 'mp4' | ''
    subtitles: List[str] = field(default_factory=list)
    inputstream: str = ''  # fMP4 HLS needs Adaptive's fragment-aware seek path.
