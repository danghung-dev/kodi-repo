"""Option → embed → stream. Nothing here is cached: media URLs expire."""
import urllib.parse

from .errors import ResolverUnavailable
from .resolvers.base import find_resolver


def resolve_option(provider, option, http, resolvers):
    """Resolve ``option`` at play time and return a ResolvedStream."""
    embed_url = provider.get_embed_url(option)
    resolver = find_resolver(embed_url, resolvers)
    if resolver is None:
        host = urllib.parse.urlsplit(embed_url).hostname
        raise ResolverUnavailable('Máy chủ phát chưa được hỗ trợ: %s' % host)
    return resolver.resolve(embed_url, option.source.get('referer', ''), http)


def pick_options(options, show_all, preferred_group=''):
    """Filter and order options: preferred language first, source order kept."""
    shown = [o for o in options if show_all or o.default_enabled]
    return sorted(shown, key=lambda o: 0 if preferred_group and o.group == preferred_group else 1)
