"""Provider contract. Providers parse one website; they never touch Kodi."""
import urllib.parse


class Provider:
    provider_id = ''
    name = ''

    def __init__(self, http, base_url, settings=None):
        self.http = http
        self.base_url = base_url.rstrip('/')
        self.settings = settings or {}
        self.host = (urllib.parse.urlsplit(self.base_url).hostname or '').lower()

    def owns_url(self, url):
        """True for an https URL on this provider's catalog host."""
        parts = urllib.parse.urlsplit(url or '')
        return parts.scheme == 'https' and (parts.hostname or '').lower() == self.host \
            and not parts.username and not parts.password

    def get_sections(self):
        raise NotImplementedError

    def list_titles(self, url):
        raise NotImplementedError

    def get_genres(self):
        raise NotImplementedError

    def search(self, query):
        raise NotImplementedError

    def get_title(self, url):
        raise NotImplementedError

    def get_playback_options(self, episode_url):
        raise NotImplementedError

    def get_embed_url(self, option):
        """Ask the source which player host serves ``option`` (plain HTTP step)."""
        raise NotImplementedError
