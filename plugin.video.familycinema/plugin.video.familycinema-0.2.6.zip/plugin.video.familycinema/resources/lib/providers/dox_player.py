"""Helpers shared by sites whose watch page calls ``loadPlayer`` (``dox_ajax_player``)."""

import re
import urllib.parse

from .. import htmldom
from ..errors import ParseError

_ENDPOINT_RE = re.compile(r'\burl\s*:\s*([\'"])([^\'"]*/player/player\.php)\1')
_SCRIPT_RE = re.compile(r"<script\b[^>]*>(.*?)</script\s*>", re.S | re.I)


def norm_url(url):
    parts = urllib.parse.urlsplit(url)
    return urllib.parse.urlunsplit(
        (parts.scheme, parts.netloc.lower(), parts.path.rstrip("/"), parts.query, "")
    )


def language_group(label):
    lowered = label.strip(" #:").lower()
    if lowered.startswith("vietsub"):
        return "Vietsub"
    if lowered.startswith("thuyết minh"):
        return "Thuyết minh"
    return "Khác"


def player_script(html):
    """The inline script that defines ``loadPlayer``, or None."""
    return next(
        (
            s
            for s in _SCRIPT_RE.findall(html)
            if re.search(r"function\s+loadPlayer\s*\(", s) and "dox_ajax_player" in s
        ),
        None,
    )


def player_endpoint(script):
    match = _ENDPOINT_RE.search(script) if script else None
    return match.group(2) if match else None


def embed_url(html, absolute):
    """The https iframe a player response points at; ``absolute`` resolves it."""
    frame = htmldom.parse(html).select_one("iframe[src]")
    if not frame:
        raise ParseError("Phản hồi player không có iframe.")
    url = absolute(frame.get("src"))
    parts = urllib.parse.urlsplit(url)
    if parts.scheme != "https" or parts.username or parts.password:
        raise ParseError("Iframe player không dùng HTTPS.")
    return url
