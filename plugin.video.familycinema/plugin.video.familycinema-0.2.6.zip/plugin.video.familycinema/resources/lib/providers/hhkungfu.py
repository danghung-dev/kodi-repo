"""HHKUNGFU provider. Selectors come from the pages captured in tests/fixtures."""

import re
import urllib.parse

from .. import htmldom
from ..errors import ParseError
from ..models import CatalogItem, Episode, Page, PlaybackOption, Section, TitleDetails
from . import dox_player
from .base import Provider

CATALOG_TTL = 300
DETAIL_TTL = 3600
GENRES_TTL = 86400

# Verified: ``tiktik`` (1080P V1) on the same Streamfree host as YanHH3D. The other
# types the page lists stay hidden unless the user opts in (playback unverified).
DEFAULT_TYPES = frozenset(("tiktik",))


class HHKungfu(Provider):
    provider_id = "hhkungfu"
    name = "HHKungfu"
    DEFAULT_BASE_URL = "https://hhkungfu.ee"

    # ----- navigation -------------------------------------------------

    def get_sections(self):
        base = self.base_url
        return [
            Section("latest", "Mới cập nhật", "list", base + "/moi-cap-nhat"),
            Section("search", "Tìm kiếm", "search"),
            Section("genres", "Thể loại", "genres"),
            Section("completed", "Phim đã hoàn thành", "list", base + "/hoan-thanh"),
            Section("top", "Top xem nhiều", "list", base + "/top-xem-nhieu"),
        ]

    def list_titles(self, url):
        return self.parse_list(self._get(url, CATALOG_TTL), url)

    def search(self, query):
        url = "%s/?%s" % (self.base_url, urllib.parse.urlencode({"s": query}))
        return self.list_titles(url)

    def get_genres(self):
        return self.parse_genres(self._get(self.base_url + "/", GENRES_TTL))

    # ----- title details ----------------------------------------------

    def get_title(self, url):
        return self.parse_title(self._get(url, DETAIL_TTL), url)

    # ----- playback options -------------------------------------------

    def get_playback_options(self, episode_url):
        return self.parse_options(self._get(episode_url, 0), episode_url)

    def get_embed_url(self, option):
        html = self.http.get_text(
            option.source["player_url"],
            referer=option.source["referer"],
            allowed_hosts={self.host},
        )
        return self.parse_embed(html, option.source["player_url"])

    # ----- fetch helper -----------------------------------------------

    def _get(self, url, ttl):
        return self.http.get_text(
            url, referer=self.base_url + "/", allowed_hosts={self.host}, cache_ttl=ttl
        )

    def _absolute(self, href, base):
        return urllib.parse.urldefrag(urllib.parse.urljoin(base, href.strip()))[0]

    # ----- parsers (pure; exercised by tests/test_hhkungfu.py) ---------

    def parse_list(self, html, page_url):
        doc = htmldom.parse(html)
        items, seen = [], set()
        # The home page also repeats the cards in a schedule box: first box with cards wins.
        for box in doc.select(".halim_box"):
            for card in box.select("article"):
                item = self._parse_card(card, page_url)
                if item and item.url not in seen:
                    seen.add(item.url)
                    items.append(item)
            if items:
                break
        heading = doc.select_one(".section-bar .section-title")
        nxt = doc.select_one("ul.page-numbers a.next")
        next_url = (
            self._absolute(nxt.get("href"), page_url)
            if nxt and nxt.get("href")
            else None
        )
        if next_url and not self.owns_url(next_url):
            next_url = None
        return Page(items, next_url, heading.text() if heading else "")

    def _parse_card(self, card, page_url):
        link = card.select_one("a.halim-thumb")
        if not link or not link.get("href"):
            return None
        url = self._absolute(link.get("href"), page_url)
        if not self.owns_url(url):
            return None
        name = card.select_one(".entry-title")
        title = (name.text() if name else "") or link.get("title", "").strip()
        if not title:
            return None
        original = card.select_one(".original_title")
        image = card.select_one("img.film-poster-img")
        poster = (
            self._absolute(image.get("src"), page_url)
            if image and image.get("src")
            else ""
        )
        label = " · ".join(
            filter(
                None,
                [
                    node.text()
                    for node in (
                        card.select_one(".episode"),
                        card.select_one(".status"),
                    )
                    if node
                ],
            )
        )
        return CatalogItem(
            self.provider_id,
            urllib.parse.urlsplit(url).path.strip("/").rsplit("/", 1)[-1],
            url,
            title,
            original.text() if original else "",
            poster,
            label,
        )

    def parse_genres(self, html):
        doc = htmldom.parse(html)
        genres, seen = [], set()
        for link in doc.select("li.menu-item-has-children > ul.dropdown-menu > li > a"):
            if "menu-item-object-category" not in link.parent.classes:
                continue
            url = self._absolute(link.get("href", ""), self.base_url + "/")
            if self.owns_url(url) and url not in seen:
                seen.add(url)
                genres.append(
                    Section(
                        urllib.parse.urlsplit(url).path.strip("/"),
                        link.text(),
                        "list",
                        url,
                    )
                )
        if not genres:
            raise ParseError(
                "Không đọc được danh sách thể loại; giao diện website có thể đã đổi."
            )
        return genres

    def parse_title(self, html, page_url):
        doc = htmldom.parse(html)
        heading = doc.select_one(".movie-detail h1.entry-title")
        if not heading:
            raise ParseError(
                "Không đọc được trang phim; giao diện website có thể đã đổi."
            )
        original = doc.select_one(".movie-detail h2.org_title")
        image = doc.select_one(".movie-poster img.film-poster-img")
        slug = urllib.parse.urlsplit(page_url).path.strip("/").rsplit("/", 1)[-1]
        item = CatalogItem(
            self.provider_id,
            slug,
            page_url,
            heading.text(),
            original.text() if original else "",
            self._absolute(image.get("src"), page_url)
            if image and image.get("src")
            else "",
        )
        plot = doc.select_one(".entry-content .halim-entry-box")
        schedule = doc.select_one(".halim_showtime_movies")
        status = ""
        for row in doc.select(".movie-detail .hh3d-info"):
            cells = row.select("div")
            if (
                len(cells) >= 2
                and cells[0].text().rstrip(":").strip().lower() == "tình trạng"
            ):
                status = cells[1].text()
        return TitleDetails(
            item,
            plot.text() if plot else "",
            [a.text() for a in doc.select(".movie-detail .list_cate a")],
            status,
            "",
            schedule.text() if schedule else "",
            self._episodes(doc, page_url),
            [],
        )

    def _episodes(self, doc, page_url):
        """One entry per episode id: the same episode in two languages is one item."""
        episodes, seen = [], set()
        for link in doc.select("#halim-list-server ul.halim-list-eps a[data-ep]"):
            href, ep = link.get("href"), link.get("data-ep")
            if not href or ep in seen:
                continue
            url = self._absolute(href, page_url)
            if not self.owns_url(url):
                continue
            seen.add(ep)
            episodes.append(
                Episode(
                    self.provider_id,
                    ep,
                    link.get("title", "").strip() or link.text() or ep,
                    url,
                    "",
                    len(episodes),
                    link.get("data-post-id", ""),
                )
            )
        return episodes

    def parse_options(self, html, watch_url):
        doc = htmldom.parse(html)
        links = doc.select("#halim-list-server ul.halim-list-eps a[data-ep]")
        watch = dox_player.norm_url(watch_url)
        current = next(
            (
                link
                for link in links
                if link.get("href")
                and dox_player.norm_url(self._absolute(link.get("href"), watch_url))
                == watch
            ),
            None,
        )
        if not current or not current.get("data-post-id"):
            raise ParseError("Trang tập không có data-post-id/data-ep khớp URL tập.")
        script = dox_player.player_script(html)
        endpoint = dox_player.player_endpoint(script)
        if not endpoint:
            raise ParseError(
                "Không tìm thấy endpoint loadPlayer; cần cập nhật provider."
            )
        player_url = self._absolute(endpoint, watch_url)
        if not self.owns_url(player_url):
            raise ParseError("Endpoint player không cùng máy chủ với website.")
        types = []
        for button in doc.select("#halim-ajax-list-server .get-eps"):
            kind = button.get("data-type")
            if kind and kind not in [t for t, _ in types]:
                types.append((kind, button.text()))
        if not types:
            raise ParseError("Trang tập không có nút server.")
        # The same episode in another language has its own page (``-sv2.html``) and sv.
        siblings = [
            link
            for link in links
            if link.get("data-ep") == current.get("data-ep")
            and link.get("data-post-id") == current.get("data-post-id")
        ]
        options = []
        for link in siblings:
            sv = link.get("data-sv", "")
            if not re.fullmatch(r"\d+", sv):
                raise ParseError(
                    "Không xác định được nhóm ngôn ngữ (sv) của trang tập."
                )
            group = dox_player.language_group(self._server_name(link))
            referer = (
                watch_url
                if link is current
                else self._absolute(link.get("href"), watch_url)
            )
            for kind, label in types:
                query = urllib.parse.urlencode(
                    [
                        ("action", "dox_ajax_player"),
                        ("post_id", link.get("data-post-id")),
                        ("chapter_st", link.get("data-ep")),
                        ("sv", sv),
                        ("type", kind),
                    ]
                )
                options.append(
                    PlaybackOption(
                        self.provider_id,
                        "%s-sv%s" % (kind, sv),
                        "%s %s" % (group, label),
                        group,
                        kind in DEFAULT_TYPES,
                        {
                            "player_url": "%s?%s" % (player_url, query),
                            "referer": referer,
                        },
                    )
                )
        return options

    @staticmethod
    def _server_name(link):
        server = next(
            (n for n in link.ancestors() if "halim-server" in n.classes), None
        )
        name = server.select_one(".halim-server-name") if server else None
        return name.text() if name else ""

    def parse_embed(self, html, base_url):
        return dox_player.embed_url(html, lambda href: self._absolute(href, base_url))
