"""Loopback HLS relay for the reviewed Streamfree TS and fragmented-MP4 formats.

The Kodi service owns it, not the short-lived plugin invocation. Signed URLs
and keys stay in memory. HTTP clients can request only registered segment IDs.
"""

import base64
import hmac
import json
import re
import secrets
import threading
import time
import urllib.parse
from collections import OrderedDict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .errors import FamilyCinemaError
from .http_client import HttpClient
from .resolvers.streamfree import HOSTS, PreparedMedia
from .resolvers.streamfree_crypto import require
from .resolvers.streamfree_media import (
    KEY_FORMAT,
    media_host_allowed,
    validate_media_url,
    _attributes,
)
from .resolvers.streamfree_transport import (
    normalize_segment,
    split_initialization,
    validate_initialization,
)

MAX_SESSIONS = 3
IDLE_TIMEOUT = 1800
MAX_LIFETIME = 6 * 3600
MAX_CACHE_BYTES = 16 * 1024 * 1024
MAX_REGISTRATION = 4 * 1024 * 1024


def local_playlist(media, session_id):
    """Only rewrite v2 wrapper VOD; never remove keys from arbitrary HLS."""
    require(
        media.playlist.startswith("#EXTM3U") and "#EXT-X-ENDLIST" in media.playlist,
        "proxy-vod-required",
    )
    require(0 < len(media.urls) <= 10000, "proxy-segment-count")
    require(media.container in ("mpegts", "fmp4"), "proxy-container")
    lines, index, keyed, pending = [], 0, False, False
    for line in media.playlist.splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith("#EXT-X-KEY:"):
            attrs = _attributes(line.split(":", 1)[1])
            require(
                attrs.get("METHOD") in ("SAMPLE-AES", "SAMPLE-AES-CTR")
                and attrs.get("KEYFORMAT") == KEY_FORMAT
                and attrs.get("URI", "").startswith("data:"),
                "proxy-key-format",
            )
            keyed = True
            continue
        if line.startswith("#"):
            require(
                "URI=" not in line
                and not line.startswith(
                    (
                        "#EXT-X-MAP",
                        "#EXT-X-BYTERANGE",
                        "#EXT-X-STREAM-INF",
                        "#EXT-X-PART",
                        "#EXT-X-I-FRAMES-ONLY",
                    )
                ),
                "proxy-playlist-format",
            )
            if line.startswith("#EXTINF:"):
                require(not pending, "proxy-missing-segment")
                pending = True
            if line.startswith("#EXT-X-VERSION:") and media.container == "fmp4":
                continue
            lines.append(line)
            if line == "#EXTM3U" and media.container == "fmp4":
                lines.extend(
                    ("#EXT-X-VERSION:7", '#EXT-X-MAP:URI="/s/%s/init.mp4"' % session_id)
                )
            continue
        wrapper = urllib.parse.urlsplit(urllib.parse.urljoin(media.referer, line))
        require(
            keyed
            and pending
            and wrapper.scheme == "https"
            and wrapper.hostname in HOSTS
            and wrapper.netloc == urllib.parse.urlsplit(media.referer).netloc
            and wrapper.path.startswith("/hls/")
            and urllib.parse.parse_qs(wrapper.query).get("v") == ["2"],
            "proxy-wrapper-format",
        )
        extension = "m4s" if media.container == "fmp4" else "ts"
        lines.append("/s/%s/segment/%s.%s" % (session_id, index, extension))
        index += 1
        pending = False
    require(index == len(media.urls) and not pending, "proxy-segment-count")
    return ("\n".join(lines) + "\n").encode("utf-8")


class _Session:
    def __init__(self, media, session_id, http, now):
        require(
            urllib.parse.urlsplit(media.referer).scheme == "https"
            and urllib.parse.urlsplit(media.referer).hostname in HOSTS,
            "proxy-referer",
        )
        require(
            0 < len(media.user_agent) <= 512
            and "\r" not in media.user_agent
            and "\n" not in media.user_agent,
            "proxy-user-agent",
        )
        for url in media.urls:
            validate_media_url(url)
        require(media.container in ("mpegts", "fmp4"), "proxy-container")
        self.initialization = b""
        if media.container == "fmp4":
            self.initialization = validate_initialization(
                base64.b64decode(media.initialization, validate=True)
            )
        else:
            require(not media.initialization, "proxy-init-container")
        self.renditions = (
            split_initialization(self.initialization) if self.initialization else {}
        )
        self.media, self.http = media, http
        self.playlist = local_playlist(media, session_id)
        self.master = (
            "#EXTM3U\n#EXT-X-VERSION:7\n"
            '#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="audio",NAME="Original",DEFAULT=YES,AUTOSELECT=YES,URI="audio.m3u8"\n'
            '#EXT-X-STREAM-INF:BANDWIDTH=8000000,AUDIO="audio"\nvideo.m3u8\n'
        ).encode()
        self.created = self.touched = now
        self.cache = OrderedDict()
        self.cache_bytes = 0
        self.lock = threading.Lock()

    def segment(self, index):
        with self.lock:
            if index in self.cache:
                self.cache.move_to_end(index)
                return self.cache[index]
            raw = self.http.get_bytes(
                self.media.urls[index],
                referer=self.media.referer,
                allowed_hosts=media_host_allowed,
            )
            data = normalize_segment(
                raw, self.media.container, self.media.transform_key
            )
            self.cache[index] = data
            self.cache_bytes += len(data)
            while len(self.cache) > 8 or self.cache_bytes > MAX_CACHE_BYTES:
                _, removed = self.cache.popitem(last=False)
                self.cache_bytes -= len(removed)
            return data


class PlaybackProxy:
    def __init__(self, http_factory=None, clock=time.monotonic):
        self.token = secrets.token_urlsafe(32)
        self.http_factory = http_factory or (
            lambda ua: HttpClient(user_agent=ua, retries=1)
        )
        self.clock = clock
        self.sessions = {}
        self.lock = threading.Lock()
        self.registration_lock = threading.Lock()
        self.slots = threading.BoundedSemaphore(8)
        self.server = self.thread = None

    @property
    def port(self):
        return self.server.server_address[1]

    def start(self, port=0):
        require(self.server is None, "proxy-already-started")
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def setup(self):
                super().setup()
                self.connection.settimeout(40)

            def log_message(self, *_args):
                pass  # Never log session paths or upstream URLs.

            def reply(self, status, body=b"", mime="text/plain", extra=None):
                try:
                    self.send_response(status)
                    self.send_header("Content-Type", mime)
                    self.send_header("Content-Length", str(len(body)))
                    self.send_header("Cache-Control", "no-store")
                    for name, value in (extra or {}).items():
                        self.send_header(name, value)
                    self.end_headers()
                    if self.command != "HEAD":
                        self.wfile.write(body)
                except OSError:
                    # Players cancel in-flight segment requests during seek/stop.
                    # Do not send a second response or log it as an upstream error.
                    self.close_connection = True

            def authorized(self):
                return hmac.compare_digest(
                    self.headers.get("Authorization", ""), "Bearer " + owner.token
                )

            def do_POST(self):
                if self.path != "/session" or not self.authorized():
                    self.reply(403)
                    return
                if self.headers.get_content_type() != "application/json":
                    self.reply(415)
                    return
                try:
                    size = int(self.headers.get("Content-Length", "0"))
                    require(0 < size <= MAX_REGISTRATION, "proxy-request-size")
                    document = json.loads(self.rfile.read(size))
                    media = PreparedMedia(
                        document["playlist"],
                        document["urls"],
                        document["referer"],
                        document["user_agent"],
                        float(document["duration"]),
                        document.get("initialization", ""),
                        document.get("transform_key", ""),
                        document.get("container", "mpegts"),
                    )
                    require(
                        isinstance(media.playlist, str)
                        and isinstance(media.urls, list)
                        and all(isinstance(url, str) for url in media.urls),
                        "proxy-request-type",
                    )
                    url = owner.add_media(media)
                    self.reply(
                        201,
                        json.dumps({"url": url}).encode("utf-8"),
                        "application/json",
                    )
                except (FamilyCinemaError, ValueError, TypeError, KeyError, OSError):
                    self.reply(502, b"Could not prepare playback session")

            def do_GET(self):
                if self.path == "/health":
                    self.reply(200 if self.authorized() else 403)
                    return
                match = re.fullmatch(
                    r"/s/([A-Za-z0-9_-]+)/(?:(index\.m3u8|video\.m3u8|audio\.m3u8)|(init\.mp4|video-init\.mp4|audio-init\.mp4)|segment/(\d+)\.(ts|m4s))",
                    self.path,
                )
                if not match:
                    self.reply(404)
                    return
                with owner.lock:
                    session = owner.sessions.get(match[1])
                    if session and not owner.expired(session):
                        session.touched = owner.clock()
                    else:
                        session = None
                if session is None:
                    self.reply(410, b"Playback session expired; select episode again")
                    return
                if match[2]:
                    body = session.playlist
                    if session.renditions:
                        if match[2] == "index.m3u8":
                            body = session.master
                        else:
                            track = match[2].split(".")[0]
                            body = body.replace(
                                b"/init.mp4", ("/" + track + "-init.mp4").encode()
                            )
                    elif match[2] != "index.m3u8":
                        self.reply(404)
                        return
                    self.reply(200, body, "application/vnd.apple.mpegurl")
                    return
                index = int(match[4]) if match[4] is not None else None
                if index is not None and (
                    not 0 <= index < len(session.media.urls)
                    or match[5]
                    != ("m4s" if session.media.container == "fmp4" else "ts")
                ):
                    self.reply(404)
                    return
                if match[3] and not session.initialization:
                    self.reply(404)
                    return
                try:
                    if match[3]:
                        if match[3] == "init.mp4":
                            data = session.initialization
                        else:
                            data = session.renditions.get(match[3].split("-")[0])
                            if data is None:
                                self.reply(404)
                                return
                    else:
                        with owner.slots:
                            data = session.segment(index)
                    mime = (
                        "video/mp4"
                        if session.media.container == "fmp4"
                        else "video/mp2t"
                    )
                    headers = {"Accept-Ranges": "bytes"}
                    requested = self.headers.get("Range")
                    if requested:
                        requested = re.fullmatch(r"bytes=(\d*)-(\d*)", requested)
                        if not requested or not any(requested.groups()):
                            self.reply(
                                416, extra={"Content-Range": "bytes */%s" % len(data)}
                            )
                            return
                        left, right = requested.groups()
                        start = int(left) if left else max(0, len(data) - int(right))
                        end = (
                            min(int(right), len(data) - 1)
                            if left and right
                            else len(data) - 1
                        )
                        if start > end or start >= len(data):
                            self.reply(
                                416, extra={"Content-Range": "bytes */%s" % len(data)}
                            )
                            return
                        headers["Content-Range"] = "bytes %s-%s/%s" % (
                            start,
                            end,
                            len(data),
                        )
                        self.reply(206, data[start : end + 1], mime, headers)
                    else:
                        self.reply(200, data, mime, headers)
                except (FamilyCinemaError, ValueError, OSError):
                    self.reply(502, b"Upstream media unavailable; select episode again")

            def do_HEAD(self):
                self.do_GET()

        self.server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
        self.server.daemon_threads = True
        self.thread = threading.Thread(
            target=self.server.serve_forever, name="FamilyCinemaProxy", daemon=True
        )
        self.thread.start()
        return self

    def expired(self, session):
        now = self.clock()
        return (
            now - session.touched > IDLE_TIMEOUT or now - session.created > MAX_LIFETIME
        )

    def cleanup(self):
        with self.lock:
            self.sessions = {
                key: value
                for key, value in self.sessions.items()
                if not self.expired(value)
            }

    def add_media(self, media):
        with self.registration_lock:
            return self._add_media(media)

    def _add_media(self, media):
        self.cleanup()
        session_id = secrets.token_urlsafe(24)
        session = _Session(
            media, session_id, self.http_factory(media.user_agent), self.clock()
        )
        # Validate the declared TS/fMP4 transport before giving Kodi a playlist.
        session.segment(0)
        with self.lock:
            if len(self.sessions) >= MAX_SESSIONS:
                oldest = min(self.sessions, key=lambda key: self.sessions[key].touched)
                del self.sessions[oldest]
            self.sessions[session_id] = session
        return "http://127.0.0.1:%s/s/%s/index.m3u8" % (self.port, session_id)

    def close(self):
        if self.server is not None:
            self.server.shutdown()
            self.server.server_close()
            self.thread.join(timeout=5)
            self.server = self.thread = None
        with self.lock:
            self.sessions.clear()
