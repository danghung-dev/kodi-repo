"""Pass a prepared session to the persistent Kodi service over loopback."""

import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import asdict

from .errors import ResolverUnavailable

STATE_FILE = "playback-service.json"
RPC_PROTOCOL = 2  # Includes fMP4 initialization and source checksum transforms.


def service_state_path():
    import xbmcaddon
    import xbmcvfs

    return os.path.join(
        xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile")), STATE_FILE
    )


def publish_media(media, state_path=None, wait_seconds=3):
    state_path = state_path or service_state_path()
    deadline = time.monotonic() + wait_seconds
    while True:
        try:
            with open(state_path, encoding="utf-8") as handle:
                state = json.load(handle)
            port, token = state["port"], state["token"]
            if state.get("protocol") != RPC_PROTOCOL:
                raise ValueError("service version")
            if not isinstance(port, int) or not 1024 <= port <= 65535:
                raise ValueError("port")
            if not isinstance(token, str) or not 32 <= len(token) <= 128:
                raise ValueError("token")
            break
        except (OSError, ValueError, KeyError, TypeError):
            if time.monotonic() >= deadline:
                raise ResolverUnavailable(
                    "Dịch vụ phát Family Cinema chưa chạy. Hãy bật lại add-on hoặc khởi động lại Kodi."
                ) from None
            time.sleep(0.1)
    payload = json.dumps(
        asdict(media), ensure_ascii=False, separators=(",", ":")
    ).encode("utf-8")
    request = urllib.request.Request(
        "http://127.0.0.1:%s/session" % port,
        data=payload,
        headers={
            "Authorization": "Bearer " + token,
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        # Local RPC must not be routed through HTTP_PROXY or follow redirects.
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *args, **kwargs):
                return None

        opener = urllib.request.build_opener(
            urllib.request.ProxyHandler({}), NoRedirect()
        )
        with opener.open(request, timeout=45) as response:
            result = json.loads(response.read(4096))["url"]
        parts = urllib.parse.urlsplit(result)
        if (
            parts.scheme != "http"
            or parts.hostname != "127.0.0.1"
            or parts.port != port
            or parts.username
            or parts.password
            or not parts.path.startswith("/s/")
            or not parts.path.endswith("/index.m3u8")
            or parts.query
            or parts.fragment
        ):
            raise ValueError("response")
        return result
    except (OSError, ValueError, KeyError, TypeError, urllib.error.URLError):
        raise ResolverUnavailable(
            "Không tạo được phiên phát. Kiểm tra dịch vụ Family Cinema và chọn lại tập."
        ) from None
