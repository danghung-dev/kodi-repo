"""Resolver contract: turn a player-host embed URL into a playable stream."""


class Resolver:
    name = ''

    def can_handle(self, embed_url):
        raise NotImplementedError

    def resolve(self, embed_url, referer, http):
        """Return a ResolvedStream or raise ResolverUnavailable / NetworkError."""
        raise NotImplementedError


def find_resolver(embed_url, resolvers):
    for resolver in resolvers:
        if resolver.can_handle(embed_url):
            return resolver
    return None
