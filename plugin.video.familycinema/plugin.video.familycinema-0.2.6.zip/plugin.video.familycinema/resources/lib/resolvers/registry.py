from .streamfree import StreamfreeResolver


def default_resolvers():
    return [StreamfreeResolver()]
