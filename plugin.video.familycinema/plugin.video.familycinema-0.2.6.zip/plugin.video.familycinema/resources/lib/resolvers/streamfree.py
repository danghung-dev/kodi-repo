"""Native Python resolver for the reviewed Streamfree v2 player protocol."""

import base64
import hashlib
import re
import time
import urllib.parse
from dataclasses import dataclass, field

from ..errors import ResolverUnavailable
from ..htmldom import parse
from ..http_client import USER_AGENT
from ..models import ResolvedStream
from .base import Resolver
from .streamfree_crypto import (
    client_nonce,
    decrypt_base65,
    environment_key,
    pack_environment,
    require,
)
from .streamfree_media import decrypt_manifest, parse_playlist, resolve_segment
from .streamfree_program import collect_environment, decode_program
from .streamfree_transport import validate_initialization

HOSTS = frozenset(("streamfree.vip", "streamfreevip.vip"))
BUNDLE_SHA256 = "1e9195d5d1431bb71a3834e786d654b93c3730a88ad0f2e507bccc7126d5325b"


@dataclass(frozen=True)
class PreparedMedia:
    playlist: str = field(repr=False)
    urls: list = field(repr=False)
    referer: str = field(repr=False)
    user_agent: str
    duration: float
    initialization: str = field(default="", repr=False)  # Base64 for loopback JSON RPC.
    transform_key: str = field(default="", repr=False)  # Decrypted data-checksum hex.
    container: str = "mpegts"


class StreamfreeResolver(Resolver):
    name = "streamfree"

    def __init__(self, publisher=None):
        self.publisher = publisher

    def can_handle(self, embed_url):
        try:
            parts = urllib.parse.urlsplit(embed_url)
            return (
                parts.scheme == "https"
                and (parts.hostname or "").lower() in HOSTS
                and not parts.username
                and not parts.password
                and parts.port in (None, 443)
            )
        except ValueError:
            return False

    def resolve(self, embed_url, referer, http):
        media = self.prepare(embed_url, referer, http)
        if self.publisher is None:
            from ..proxy_client import publish_media

            url = publish_media(media)
        else:
            url = self.publisher(media)
        return ResolvedStream(
            url,
            mime="application/vnd.apple.mpegurl",
            protocol="hls",
            inputstream="inputstream.adaptive" if media.container == "fmp4" else "",
        )

    def prepare(self, embed_url, referer, http):
        require(self.can_handle(embed_url), "embed-host")
        try:
            return self._prepare(embed_url, referer, http)
        except (
            ValueError,
            KeyError,
            IndexError,
            TypeError,
            UnicodeError,
            OverflowError,
        ) as error:
            # Never surface nonce, bytecode, signed URL or key bytes in UI/logs.
            raise ResolverUnavailable(
                "Streamfree: dữ liệu player không hợp lệ hoặc giao thức đã thay đổi"
            ) from error

    def _prepare(self, embed_url, referer, http):
        html = http.get_text(embed_url, referer=referer, allowed_hosts=HOSTS)
        require(len(html) <= 2 * 1024 * 1024, "embed-size")
        document = parse(html)
        player, meta = (
            document.select_one("#hrm-player"),
            document.select_one("meta[name=bytecode]"),
        )
        require(player is not None and meta is not None, "player-configuration")
        attrs = player.attrs
        required = ("data-id", "data-nonce", "data-uip", "data-time", "data-video-id")
        require(
            all(attrs.get(key) for key in required) and meta.get("content"),
            "player-configuration",
        )
        require(
            len(attrs["data-id"]) <= 4096
            and len(meta.get("content")) <= 8192
            and len(attrs["data-nonce"]) <= 512
            and len(attrs["data-uip"]) <= 128
            and len(attrs["data-time"]) <= 16
            and len(attrs["data-video-id"]) <= 255,
            "player-configuration-size",
        )
        script = next(
            (
                node.get("src")
                for node in document.select("script[src]")
                if re.search(r"/static/app\.[\da-f]+\.js$", node.get("src", ""))
            ),
            None,
        )
        require(script is not None, "player-bundle-missing")
        bundle_url = urllib.parse.urljoin(embed_url, script)
        bundle = http.get_text(
            bundle_url, referer=embed_url, allowed_hosts=HOSTS, cache_ttl=3600
        )
        require(
            hashlib.sha256(bundle.encode("utf-8")).hexdigest() == BUNDLE_SHA256,
            "player-bundle-changed; cần cập nhật resolver",
        )
        host = urllib.parse.urlsplit(embed_url).hostname
        user_agent = getattr(http, "user_agent", USER_AGENT)
        first_key = environment_key(host, user_agent, attrs["data-time"])
        media_id = decrypt_base65(attrs["data-id"], first_key).decode("utf-8")
        require(bool(re.fullmatch(r"[A-Za-z0-9_-]{1,512}", media_id)), "media-id")
        second_key = environment_key(
            host, user_agent, media_id, (attrs["data-id"], attrs["data-nonce"])
        )
        program = decrypt_base65(meta.get("content"), second_key)
        steps = decode_program(program, media_id)
        sample = collect_environment(steps, host)
        payload = pack_environment(sample, attrs["data-video-id"])
        digest = hashlib.md5(
            (str(sample[13]) + attrs["data-uip"]).encode("utf-8")
        ).hexdigest()
        final_key = environment_key(host, user_agent, digest)
        now = int(time.time() * 1000)
        params = {
            "vid": attrs["data-video-id"],
            "dt": now - int(attrs["data-time"]),
            "snonce": attrs["data-nonce"],
            "cnonce": client_nonce(payload, final_key),
            "hash": digest,
            "uid": sample[15],
            "ct": now,
        }
        manifest_url = urllib.parse.urljoin(embed_url, "/hls/" + media_id + ".m3u8")
        body = http.get_text(
            manifest_url + "?" + urllib.parse.urlencode(params),
            referer=embed_url,
            allowed_hosts=HOSTS,
        )
        require(len(body) <= 4 * 1024 * 1024, "manifest-size")
        manifest = decrypt_manifest(body, attrs["data-nonce"], with_initialization=True)
        playlist = manifest.playlist
        segments, duration = parse_playlist(
            playlist, embed_url, attrs["data-nonce"], sample
        )
        urls = [
            resolve_segment(segment, attrs["data-video-id"]) for segment in segments
        ]
        initialization, transform_key, container = "", "", "mpegts"
        if attrs.get("data-checksum"):
            require(len(attrs["data-checksum"]) <= 4096, "player-checksum-size")
            transform_key = decrypt_base65(
                attrs["data-checksum"], second_key[::-1]
            ).decode("ascii")
            require(
                bool(
                    re.fullmatch(
                        r"(?:[0-9a-fA-F]{32}|[0-9a-fA-F]{48}|[0-9a-fA-F]{64})",
                        transform_key,
                    )
                ),
                "player-checksum-key",
            )
        if manifest.initialization:
            validate_initialization(manifest.initialization)
            initialization = base64.b64encode(manifest.initialization).decode("ascii")
            container = "fmp4"
        return PreparedMedia(
            playlist,
            urls,
            embed_url,
            user_agent,
            duration,
            initialization,
            transform_key,
            container,
        )
