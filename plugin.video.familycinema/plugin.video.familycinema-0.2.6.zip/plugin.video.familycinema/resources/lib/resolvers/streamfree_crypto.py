"""Python implementation of the pinned Streamfree wire codec.

Protocol reference: app.914fc635.js, SHA256
1e9195d5d1431bb71a3834e786d654b93c3730a88ad0f2e507bccc7126d5325b.
No JavaScript is evaluated. Cryptodome is supplied by Kodi's crypto module.
"""

import base64
import hashlib
import hmac
import json
import os
import re
import struct

from ..errors import ResolverUnavailable

MASK32 = 0xFFFFFFFF
MASK64 = 0xFFFFFFFFFFFFFFFF
ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_~"


def require(condition, code):
    if not condition:
        raise ResolverUnavailable("Streamfree: %s" % code)


def b64decode(value):
    value = value.replace("-", "+").replace("_", "/")
    return base64.b64decode(value + "=" * (-len(value) % 4), validate=True)


def padded_nonce(value):
    value = value.replace("-", "+").replace("_", "/")
    return value + "=" * (-len(value) % 4)


def hkdf(secret, salt, info, size):
    prk = hmac.new(salt, secret, hashlib.sha256).digest()
    out, block = b"", b""
    for index in range(1, (size + 31) // 32 + 1):
        block = hmac.new(prk, block + info + bytes([index]), hashlib.sha256).digest()
        out += block
    return out[:size]


def environment_key(host, user_agent, salt, extras=()):
    # init:false in the reference client fixes these seven input booleans.
    env = json.dumps(
        [user_agent, host] + [False] * 7, ensure_ascii=False, separators=(",", ":")
    ).encode("utf-8")
    suffix = b""
    for item in extras:
        item = item.encode("utf-8") if isinstance(item, str) else item
        suffix += struct.pack(">I", len(item)) + item
    return hkdf(
        env + b"\0" + suffix,
        str(salt).encode("utf-8"),
        ("env-key:" + host).encode("utf-8"),
        16,
    ).hex()


def _aes(key, iv, aad=b""):
    try:
        from Cryptodome.Cipher import AES
    except ImportError as error:
        raise ResolverUnavailable(
            "Thiếu module crypto của Kodi: script.module.pycryptodome"
        ) from error
    cipher = AES.new(key, AES.MODE_GCM, nonce=iv, mac_len=16)
    if aad:
        cipher.update(aad)
    return cipher


def gcm_decrypt(key, iv, ciphertext, aad=b""):
    require(len(ciphertext) >= 16, "gcm-size")
    try:
        return _aes(key, iv, aad).decrypt_and_verify(ciphertext[:-16], ciphertext[-16:])
    except ValueError as error:
        raise ResolverUnavailable("Streamfree: gcm-auth") from error


def client_nonce(payload, secret, iv=None):
    key = secret.encode("ascii")
    iv = os.urandom(12) if iv is None else iv
    ciphertext, tag = _aes(key, iv).encrypt_and_digest(payload)
    body = ciphertext + tag
    packed = iv + body + hmac.new(key, body, hashlib.sha256).digest()
    return base64.urlsafe_b64encode(packed).decode("ascii").rstrip("=")


def base65(value):
    require(len(value) <= 2 * 1024 * 1024, "base65-size")

    def number(text):
        result = 0
        for char in text:
            require(char in ALPHABET, "base65-character")
            result = result * 65 + ALPHABET.index(char)
        return result

    def plain(text):
        zeros = len(text) - len(text.lstrip(ALPHABET[0]))
        integer = number(text)
        return b"\0" * zeros + integer.to_bytes((integer.bit_length() + 7) // 8, "big")

    if value.startswith("Z65."):
        parts = value.split(".", 2)
        require(
            len(parts) == 3 and re.fullmatch(r"[0-9a-z]+", parts[1], re.I),
            "base65-header",
        )
        size = int(parts[1], 36)
        require(size <= 1024 * 1024, "base65-size")
        widths = (0, 2, 3, 4, 6, 7, 8, 10, 11)
        full, rest = divmod(size, 8)
        require(len(parts[2]) == full * 11 + widths[rest], "base65-length")
        out, offset = bytearray(), 0
        for index in range(full + bool(rest)):
            nbytes = 8 if index < full else rest
            width = widths[nbytes]
            integer = number(parts[2][offset : offset + width])
            require(integer < 1 << (nbytes * 8), "base65-overflow")
            out.extend(integer.to_bytes(nbytes, "big"))
            offset += width
        return bytes(out)
    if value.startswith("C65."):
        parts = value.split(".")
        require(
            len(parts) >= 4
            and re.fullmatch(r"[0-9a-z]+", parts[1], re.I)
            and re.fullmatch(r"[0-9a-z]+", parts[2], re.I),
            "base65-header",
        )
        size, chunk = int(parts[1], 36), int(parts[2], 36)
        require(4096 < size <= 1024 * 1024 and 0 < chunk <= 768, "base65-chunk-size")
        require(len(parts) == 3 + (size + chunk - 1) // chunk, "base65-chunk-count")
        out = bytearray()
        for part in parts[3:]:
            decoded = plain(part)
            require(len(decoded) == min(chunk, size - len(out)), "base65-chunk-length")
            out.extend(decoded)
        return bytes(out)
    return plain(value)


def rotate(value, bits):
    bits &= 31
    value &= MASK32
    return ((value << bits) | (value >> ((32 - bits) & 31))) & MASK32


def round_function(value, key):
    value = rotate((value ^ key) + ((value ^ rotate(key, 16)) * 0x9E3779B1), 7)
    value ^= ((value + 0x7F4A7C15) & MASK32) * (key | 1) & MASK32
    return rotate(value, key >> 27)


def feistel_stream(data, keys, nonce):
    require(len(nonce) == 16 and len(keys) == 12, "feistel-input")
    n0, n1, n2, n3 = struct.unpack("<4I", nonce)
    out = bytearray()
    for counter, offset in enumerate(range(0, len(data), 8)):
        left, right = (n0 + counter + n2) & MASK32, (n1 ^ counter ^ n3) & MASK32
        for key in keys:
            left, right = right, (left ^ round_function(right ^ key, key)) & MASK32
        stream = struct.pack("<II", left, right)
        out.extend(a ^ b for a, b in zip(data[offset : offset + 8], stream))
    return bytes(out)


def decrypt_base65(value, secret):
    data = base65(value)
    require(len(data) >= 68 and data[:4] == b"B65\x01", "base65-envelope")
    salt, nonce, ciphertext, tag = data[4:20], data[20:36], data[36:-32], data[-32:]
    key = secret.encode("ascii")
    mac = hkdf(key, salt, b"mac-key", 32)
    require(
        hmac.compare_digest(hmac.new(mac, data[:-32], hashlib.sha256).digest(), tag),
        "base65-auth",
    )
    keys = struct.unpack("<12I", hkdf(key, salt, b"round-keys", 48))
    return feistel_stream(ciphertext, keys, nonce)


def pack_environment(sample, video_id):
    bits = ""
    for value in sample[:18]:
        if isinstance(value, bool):
            bits += "00" + str(int(value))
        elif isinstance(value, int):
            bits += "01" + "".join(format(b, "08b") for b in struct.pack("<i", value))
        elif isinstance(value, float):
            bits += "11" + "".join(format(b, "08b") for b in struct.pack("<d", value))
        elif isinstance(value, str):
            encoded = value.encode("utf-16-be")
            bits += "10" + format(len(encoded) // 2, "016b")
            bits += "".join(format(b, "08b") for b in encoded)
        else:
            require(False, "environment-type")
    raw = bytes(
        int(bits[index : index + 8].ljust(8, "0"), 2)
        for index in range(0, len(bits), 8)
    )
    video = bytes(ord(char) & 255 for char in video_id)
    require(bool(video), "video-id")
    return bytes(byte ^ video[index % len(video)] for index, byte in enumerate(raw))


def _splitmix(value):
    value = (value + 0x9E3779B97F4A7C15) & MASK64
    value = ((value ^ (value >> 30)) * 0xBF58476D1CE4E5B9) & MASK64
    value = ((value ^ (value >> 27)) * 0x94D049BB133111EB) & MASK64
    return value ^ (value >> 31)


def unmask_key(data, nonce, clock_start, clock_end):
    seed = int.from_bytes(
        hashlib.md5(padded_nonce(nonce).encode("ascii")).digest()[:8], "little"
    )
    seed ^= (int(clock_start) & MASK32) ^ (int(clock_end) & MASK32)
    state0 = _splitmix(seed)
    state1 = _splitmix(state0)

    def next32():
        nonlocal state0, state1
        left, right = state0, state1
        state0 = right
        left ^= (left << 23) & MASK64
        left ^= left >> 17
        left ^= right ^ (right >> 26)
        state1 = left & MASK64
        return (state0 + state1) & MASK32

    out = bytearray()
    for index, byte in enumerate(data):
        if index % 4 == 0:
            next32()
        out.append(byte ^ ((next32() >> (8 * (index % 4))) & 255))
    return bytes(out)
