"""Playlist, key packet and signed segment URL decoding for Streamfree v2."""

import base64
import hashlib
import json
import re
import struct
import time
import urllib.parse
import zlib
from dataclasses import dataclass

from .streamfree_crypto import (
    b64decode,
    gcm_decrypt,
    hkdf,
    padded_nonce,
    require,
    unmask_key,
)

URL_SALT = b"streame/segment-url"
KEY_FORMAT = "urn:uuid:2dfa3a2e-bb7a-447d-a7b1-3d15b81f5b62"


def media_host_allowed(host):
    host = (host or "").lower()
    return any(
        host == domain or host.endswith("." + domain)
        for domain in ("tiktokcdn.com", "ibyteimg.com")
    )


def validate_media_url(url):
    parts = urllib.parse.urlsplit(url)
    require(
        parts.scheme == "https"
        and media_host_allowed(parts.hostname)
        and not parts.username
        and not parts.password
        and parts.port in (None, 443)
        and not any(
            ord(char) <= 32 or ord(char) == 127 or char == "\\" for char in url
        ),
        "media-host",
    )
    return url


@dataclass(frozen=True)
class Manifest:
    playlist: str
    initialization: bytes = b""


def decrypt_manifest(body, nonce, with_initialization=False):
    if "#ENC-AESGCM" not in body:
        require(body.startswith("#EXTM3U"), "manifest-header")
        return Manifest(body) if with_initialization else body
    match = re.search(r"#ENC-AESGCM;iv=([^;\s]+)", body)
    require(match is not None, "manifest-iv")
    key = bytes.fromhex(
        hashlib.md5(padded_nonce(nonce).encode("ascii")).hexdigest()[::-1]
    )
    lines = [
        line.strip()
        for line in body.splitlines()
        if line.strip() and not line.startswith("#")
    ]
    require(len(lines) == 1, "manifest-envelope")
    plain = gcm_decrypt(key, b64decode(match[1]), b64decode(lines[0]))
    initialization = b""
    if plain.startswith(b"SMH1"):
        require(len(plain) >= 30, "manifest-smh-size")
        require(plain[4] == 1 and plain[5] & ~15 == 0, "manifest-smh-version")
        metadata_length, init_length = struct.unpack_from(">HI", plain, 8)
        offset = 30 + metadata_length
        require(
            init_length <= 1024 * 1024 and len(plain) >= offset + init_length,
            "manifest-smh-truncated",
        )
        if plain[5] & 1:
            require(
                plain[5] & 2 and init_length > 0, "manifest-external-init-unsupported"
            )
            initialization = plain[offset : offset + init_length]
        else:
            require(init_length == 0, "manifest-smh-flags")
        plain = plain[offset + init_length :]
    playlist = plain.decode("utf-8")
    require(playlist.startswith("#EXTM3U"), "manifest-header")
    return Manifest(playlist, initialization) if with_initialization else playlist


class _Reader:
    def __init__(self, data):
        self.data, self.offset = data, 0

    def take(self, size):
        require(
            size >= 0 and self.offset + size <= len(self.data), "key-packet-truncated"
        )
        out = self.data[self.offset : self.offset + size]
        self.offset += size
        return out

    def number(self, fmt):
        return struct.unpack(fmt, self.take(struct.calcsize(fmt)))[0]

    def string(self):
        return self.take(self.number("<B")).decode("utf-8")


def unwrap_key(packet, nonce, sample):
    require(24 <= len(packet) <= 65536, "key-packet-size")
    require(
        zlib.crc32(packet[:-4]) & 0xFFFFFFFF == struct.unpack("<I", packet[-4:])[0],
        "key-crc",
    )
    reader = _Reader(packet[:-4])
    require(reader.take(4) == b"USKD", "key-magic")
    reader.number("<B")  # Packet version, descriptive metadata follows.
    reader.string()  # Name.
    reader.string()  # Algorithm.
    reader.number("<I")  # Flags.
    reader.number("<B")  # Environment schema.
    reader.take(reader.number("<I"))  # Embedded environment.
    metadata = reader.take(reader.number("<I"))
    if metadata:
        require(isinstance(json.loads(metadata.decode("utf-8")), dict), "key-metadata")
    reader.number("<I")  # Key flags.
    secret = reader.take(reader.number("<I"))
    require(
        reader.offset == len(reader.data) and len(secret) in (16, 24, 32), "key-size"
    )
    return unmask_key(secret, nonce, sample[0], sample[16])


def _attributes(line):
    return {
        match[1]: match[2][1:-1] if match[2].startswith('"') else match[2]
        for match in re.finditer(r'([A-Z0-9-]+)=("[^"]*"|[^,]*)', line)
    }


@dataclass(frozen=True)
class Segment:
    wrapper: str
    sequence: int
    key: bytes
    key_id: str


def parse_playlist(playlist, embed_url, nonce, sample):
    require(
        playlist.startswith("#EXTM3U") and "#EXT-X-ENDLIST" in playlist,
        "vod-playlist-required",
    )
    require(
        not any(
            tag in playlist
            for tag in (
                "#EXT-X-MAP:",
                "#EXT-X-BYTERANGE:",
                "#EXT-X-STREAM-INF:",
                "#EXT-X-I-FRAMES-ONLY",
                "#EXT-X-PART:",
                "#EXT-X-SESSION-KEY:",
            )
        ),
        "playlist-format-unsupported",
    )
    sequence, current_key, key_id = 0, None, None
    key_cache, segments = {}, []
    duration, expect_uri = 0.0, False
    for line in playlist.splitlines():
        line = line.strip()
        if line.startswith("#EXT-X-MEDIA-SEQUENCE:"):
            require(not segments, "playlist-sequence-order")
            sequence = int(line.split(":", 1)[1])
            require(0 <= sequence <= 0xFFFFFFFF, "playlist-sequence")
        elif line.startswith("#EXT-X-KEY:"):
            attrs = _attributes(line.split(":", 1)[1])
            require(
                attrs.get("METHOD") in ("SAMPLE-AES", "SAMPLE-AES-CTR")
                and attrs.get("KEYFORMAT") == KEY_FORMAT,
                "playlist-key-format",
            )
            uri = attrs.get("URI", "")
            require(uri.startswith("data:") and ";base64," in uri, "playlist-key-uri")
            packet = base64.b64decode(uri.split(",", 1)[1], validate=True)
            if uri not in key_cache:
                key_cache[uri] = unwrap_key(packet, nonce, sample)
            current_key = key_cache[uri]
            if attrs.get("KEYID"):
                value = attrs["KEYID"].lower().removeprefix("0x")
                require(bool(re.fullmatch(r"[0-9a-f]{32}", value)), "playlist-key-id")
                key_id = value
            else:
                require(len(packet) >= 22, "playlist-key-id")
                key_id = packet[-22:-6].hex()
        elif line.startswith("#EXTINF:"):
            require(not expect_uri, "playlist-missing-uri")
            length = float(line.split(":", 1)[1].split(",", 1)[0])
            require(0 < length < 3600, "playlist-duration")
            duration += length
            expect_uri = True
        elif line and not line.startswith("#"):
            require(
                expect_uri and current_key is not None and key_id is not None,
                "playlist-segment-key",
            )
            wrapper = urllib.parse.urljoin(embed_url, line)
            parts, embed = (
                urllib.parse.urlsplit(wrapper),
                urllib.parse.urlsplit(embed_url),
            )
            require(
                parts.scheme == "https"
                and parts.netloc == embed.netloc
                and parts.path.startswith("/hls/"),
                "playlist-wrapper-host",
            )
            require(
                len(segments) < 10000 and sequence <= 0xFFFFFFFF,
                "playlist-segment-count",
            )
            segments.append(Segment(wrapper, sequence, current_key, key_id))
            sequence += 1
            expect_uri = False
    require(bool(segments) and not expect_uri, "playlist-empty-or-truncated")
    return segments, duration


def resolve_segment(segment, video_id, now_ms=None):
    query = urllib.parse.parse_qs(
        urllib.parse.urlsplit(segment.wrapper).query, keep_blank_values=True
    )

    def field(name):
        require(len(query.get(name, [])) == 1, "url-token-field")
        return query[name][0]

    require(field("v") == "2", "url-token-version")
    index, expiry = field("i"), field("x")
    require(
        index.isascii() and index.isdigit() and expiry.isascii() and expiry.isdigit(),
        "url-token-number",
    )
    index, expiry = int(index), int(expiry)
    require(
        index == segment.sequence and 0 < expiry <= (1 << 53) - 1, "url-token-binding"
    )
    require(field("k") == segment.key_id, "url-key-id")
    now_ms = int(time.time() * 1000) if now_ms is None else now_ms
    require(now_ms - expiry <= 30000, "url-token-expired")
    token = b64decode(field("e"))
    require(33 <= len(token) <= 8224 and token[:4] == b"SU\x02\x01", "url-token-header")
    video, key_id = video_id.encode("utf-8"), segment.key_id.encode("utf-8")
    require(0 < len(video) <= 255 and 0 < len(key_id) <= 128, "url-token-input-size")
    aad = (
        b"\x02"
        + struct.pack(">H", len(URL_SALT))
        + URL_SALT
        + struct.pack(">H", len(video))
        + video
        + struct.pack(">I", index)
        + struct.pack(">H", len(key_id))
        + key_id
        + struct.pack(">Q", expiry)
    )
    info = b"\x02\x01" + struct.pack(">H", len(key_id)) + key_id
    derived = hkdf(segment.key, URL_SALT, info, 32)
    target = gcm_decrypt(derived, token[4:16], token[16:], aad).decode("utf-8")
    require(0 < len(target) <= 8192, "url-target-size")
    return validate_media_url(target)
