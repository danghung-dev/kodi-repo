"""Bounded decoder for Streamfree VMW2 (12 Feistel rounds, fixed probe ISA).

The embedded program is data. Only the reviewed instruction shape is accepted;
there is no eval, JavaScript interpreter, arbitrary calls or dynamic imports.
"""

import hashlib
import struct

from .streamfree_crypto import feistel_stream, require

PROBES = {
    0x31: 0,
    0xA4: 1,
    0x57: 2,
    0xC2: 3,
    0x19: 4,
    0xE7: 5,
    0x45: 6,
    0xB8: 7,
    0x62: 8,
    0x9D: 9,
    0x2B: 10,
    0xF1: 11,
    0x74: 12,
    0x0E: 15,
    0x5C: 17,
    0x83: 16,
}
URL_MACHINE = bytes((0x91, 0x37, 0xC4, 0x5A, 0xED))


def decode_program(envelope, binding):
    require(76 <= len(envelope) <= 556, "codec-envelope-size")
    require(envelope[:8] == b"VMW2\x02\x01\x02\0", "codec-envelope-version")
    machine_size, payload_size = struct.unpack_from("<HH", envelope, 8)
    require(machine_size == 257 and 1 <= payload_size <= 96, "codec-machine-size")
    require(len(envelope) == 76 + machine_size + payload_size, "codec-envelope-length")
    require(
        hashlib.sha256(binding.encode("utf-8")).digest()[:16] == envelope[28:44],
        "codec-binding",
    )
    nonce, digest = envelope[12:28], envelope[44:76]
    machine = envelope[76 : 76 + machine_size]
    require(machine[:4] == b"WB\x01\x0c" and machine[-1] == 0xE4, "codec-machine-magic")
    keys = []
    # Each round: LOAD r1,u32; LOAD r2,u32; XOR r1,r2; ROUND r1;
    # CLEAR r1; CLEAR r2. Exactly 12 rounds and one HALT, no loops/jumps.
    for offset in range(4, 256, 21):
        group = machine[offset : offset + 21]
        require(group[0] == group[6] == 0x91, "codec-opcode")
        r1, r2 = group[1], group[7]
        require(r1 < 4 and r2 < 4 and r1 != r2, "codec-register")
        expected = bytes((0x3E, r1, r2, 0xC7, r1, 0x5B, r1, 0x5B, r2))
        require(group[12:] == expected, "codec-machine-shape")
        keys.append(
            struct.unpack_from("<I", group, 2)[0]
            ^ struct.unpack_from("<I", group, 8)[0]
        )
    payload = feistel_stream(envelope[76 + machine_size :], keys, nonce)
    require(hashlib.sha256(payload).digest() == digest, "codec-digest")
    program = bytes(byte ^ 0xBB for byte in payload)
    require(7 <= len(program) <= 96, "program-size")
    checksum = 0x6D2B
    for index, byte in enumerate(program[:-2]):
        checksum = ((checksum ^ byte) * 0x101 + index + 0x3D) & 0xFFFF
    require(
        checksum == struct.unpack_from("<H", program, len(program) - 2)[0],
        "program-checksum",
    )
    require(
        program[:6] == bytes((0xA9, 0x51, 2, 18, len(PROBES), len(URL_MACHINE))),
        "program-header",
    )
    require(
        len(program) == 6 + 3 * len(PROBES) + len(URL_MACHINE) + 3, "program-length"
    )
    steps, seen = [], set()
    for offset in range(6, 6 + 3 * len(PROBES), 3):
        opcode, probe, slot = program[offset : offset + 3]
        require(
            opcode == 0x6D
            and probe in PROBES
            and PROBES[probe] == slot
            and probe not in seen,
            "program-capability",
        )
        steps.append((probe, slot))
        seen.add(probe)
    require(steps[0][0] == 0x31 and steps[-1][0] == 0x83, "program-order")
    require(
        program[-8:-3] == URL_MACHINE and program[-3] == 0xD2, "program-url-machine"
    )
    return steps


def collect_environment(steps, host):
    # Wire values of the reviewed client profile used by the Node prototype.
    # Both clock probes use the same monotonic value; it also binds key unwrap.
    samples = {
        0x31: "1000",
        0xA4: True,
        0x57: False,
        0xC2: False,
        0x19: False,
        0xE7: False,
        0x45: False,
        0xB8: True,
        0x62: host in ("streamfree.vip", "streamfreevip.vip"),
        0x9D: False,
        0x2B: False,
        0xF1: False,
        0x74: True,
        0x0E: "123456789",
        0x5C: True,
        0x83: "1000",
    }
    result = [0] * 18
    for probe, slot in steps:
        result[slot] = samples[probe]
    return result
