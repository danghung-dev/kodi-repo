"""Media framing for the pinned Streamfree player (TS and clear fragmented MP4).

The PNG marker 0xbb uses the reverse-swap transform in player _0x34dfbf;
its key comes from data-checksum, not the playlist's segment-URL key.
"""

import struct
from array import array

from ..errors import ResolverUnavailable
from .streamfree_crypto import require

MAX_SEGMENT = 16 * 1024 * 1024


def transport_stream(raw):
    require(len(raw) <= MAX_SEGMENT, "segment-size")
    for cursor in range(min(len(raw) - 376, 4096)):
        if raw[cursor] == raw[cursor + 188] == raw[cursor + 376] == 0x47:
            return raw[cursor:]
    raise ResolverUnavailable("Streamfree: segment không có MPEG-TS hợp lệ")


def _boxes(data):
    offset, boxes = 0, []
    while offset < len(data):
        if offset + 8 > len(data):
            return None
        size, kind = struct.unpack_from(">I4s", data, offset)
        header = 8
        if size == 1:
            if offset + 16 > len(data):
                return None
            size, header = struct.unpack_from(">Q", data, offset + 8)[0], 16
        elif size == 0:
            size = len(data) - offset
        if size < header or offset + size > len(data):
            return None
        boxes.append(kind)
        offset += size
    return boxes


def validate_initialization(data):
    require(0 < len(data) <= 1024 * 1024, "mp4-init-size")
    boxes = _boxes(data)
    require(boxes and boxes[0] == b"ftyp" and b"moov" in boxes, "mp4-init-format")
    require(
        not any(marker in data for marker in (b"encv", b"enca", b"tenc")),
        "mp4-encrypted-init-unsupported",
    )
    return data


def fragmented_mp4(raw):
    require(len(raw) <= MAX_SEGMENT, "segment-size")
    # Do not accept a stray 'moof' string in a corrupt or scrambled payload.
    # A candidate must form a complete sequence of sized ISO-BMFF boxes.
    for cursor in range(min(max(0, len(raw) - 7), 4096)):
        if raw[cursor + 4 : cursor + 8] not in (b"styp", b"moof", b"sidx", b"emsg"):
            continue
        boxes = _boxes(raw[cursor:])
        if (
            boxes
            and b"moof" in boxes
            and b"mdat" in boxes
            and boxes.index(b"moof") < boxes.index(b"mdat")
            and all(
                kind in (b"styp", b"moof", b"mdat", b"sidx", b"emsg", b"prft", b"free")
                for kind in boxes
            )
        ):
            return raw[cursor:]
    raise ResolverUnavailable("Streamfree: fragment MP4 không hợp lệ")


def unshuffle_png(raw, key):
    require(len(raw) <= MAX_SEGMENT, "segment-size")
    if len(raw) < 70 or not raw.startswith(b"\x89PNG"):
        return raw
    marker = raw[70] if len(raw) > 70 else None
    data = bytearray(raw[71:] if marker in (0xAA, 0xBB) else raw[70:])
    if marker != 0xBB:
        return bytes(data)
    require(len(key) in (16, 24, 32), "segment-checksum-key")
    size = len(data)
    if size < 2:
        return bytes(data)
    count = min(size, max(size >> 3, 4 * len(key)))
    left, right = 0, size - 1
    # Packed integers bound workspace to ~one payload length, rather than a
    # Python tuple for each pair (important on Android/ARM devices).
    pairs = array("I")
    for index in range(count):
        left = (left + key[index % len(key)] + index) % size
        right = (right + key[(index + 1) % len(key)] + index + 1) % size
        if left == right:
            right = (right + 1) % size
        pairs.extend((left, right))
    for index in range(len(pairs) - 2, -1, -2):
        left, right = pairs[index], pairs[index + 1]
        data[left], data[right] = data[right], data[left]
    return bytes(data)


def normalize_segment(raw, container, transform_key=""):
    require(container in ("mpegts", "fmp4"), "segment-container")
    normalizer = fragmented_mp4 if container == "fmp4" else transport_stream
    if (
        container == "fmp4"
        and len(raw) > 70
        and raw.startswith(b"\x89PNG")
        and raw[70] == 0xBB
    ):
        # Swaps may leave box headers intact while corrupting encoded samples.
        # The source marker, not just a successful box scan, selects this path.
        return normalizer(unshuffle_png(raw, bytes.fromhex(transform_key)))
    try:
        return normalizer(raw)
    except ResolverUnavailable:
        if not transform_key:
            raise
    return normalizer(unshuffle_png(raw, bytes.fromhex(transform_key)))


def split_initialization(data):
    """Expose muxed tracks as HLS renditions for Kodi 21's MP4 reader.

    Fragment bytes and track IDs stay intact; each rendition's movie contains
    only the selected track. Bento4 can then select audio independently.
    """

    def children(blob):
        require(_boxes(blob) is not None, "mp4-box-format")
        offset = 0
        while offset < len(blob):
            size, kind = struct.unpack_from(">I4s", blob, offset)
            header = 8
            if size == 1:
                size, header = struct.unpack_from(">Q", blob, offset + 8)[0], 16
            elif size == 0:
                size = len(blob) - offset
            yield (
                kind,
                blob[offset : offset + size],
                blob[offset + header : offset + size],
            )
            offset += size

    def box(kind, payload):
        return struct.pack(">I4s", len(payload) + 8, kind) + payload

    top = list(children(data))
    movie = next(payload for kind, _, payload in top if kind == b"moov")
    parts = list(children(movie))
    tracks = {}
    for kind, raw, payload in parts:
        if kind != b"trak":
            continue
        mdia = next((p for k, _, p in children(payload) if k == b"mdia"), None)
        if mdia is None:
            continue
        handler = next((p[8:12] for k, _, p in children(mdia) if k == b"hdlr"), None)
        if handler in (b"vide", b"soun"):
            tracks[handler] = raw
    if set(tracks) != {b"vide", b"soun"}:
        return {}
    return {
        name: b"".join(
            box(
                b"moov",
                b"".join(
                    raw
                    for kind, raw, _ in parts
                    if kind != b"trak" or raw == tracks[handler]
                ),
            )
            if kind == b"moov"
            else raw
            for kind, raw, _ in top
        )
        for name, handler in (("video", b"vide"), ("audio", b"soun"))
    }
