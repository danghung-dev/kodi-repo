"""Plugin URL routing. Pure Python: the Kodi layer is injected as ``ui``.

Every URL parameter is validated: unknown provider/action is rejected and
catalog URLs must belong to the provider's host, so a crafted plugin:// URL
cannot make the add-on fetch arbitrary sites.
"""

import urllib.parse
from dataclasses import dataclass, field

from . import playback, strings
from .errors import FamilyCinemaError, RouteError
from .providers import registry
from .resolvers.registry import default_resolvers


@dataclass
class Entry:
    label: str
    params: dict
    is_folder: bool = True
    playable: bool = False
    art: dict = field(default_factory=dict)
    info: dict = field(default_factory=dict)


def build_query(params):
    return urllib.parse.urlencode(params)


def parse_query(query):
    parsed = urllib.parse.parse_qs(query.lstrip("?"), keep_blank_values=True)
    return {key: values[-1] for key, values in parsed.items()}


class Router:
    def __init__(self, ui, http, settings, resolvers=None, provider_factory=None):
        self.ui = ui
        self.http = http
        self.settings = settings
        self.resolvers = resolvers if resolvers is not None else default_resolvers()
        self._create = provider_factory or registry.create
        self._providers = {}

    # ----- entry point --------------------------------------------------

    def dispatch(self, query):
        params = parse_query(query)
        action = params.get("action", "root")
        try:
            handler = getattr(self, "_do_" + action, None) if action.isidentifier() else None
            if handler is None:
                raise RouteError("Hành động không hợp lệ: %s" % action)
            handler(params)
        except FamilyCinemaError as error:
            if action == "play":
                self.ui.play_failed()
            else:
                self.ui.show([], cancelled=True)
            self.ui.notify(str(error), error=True)

    # ----- helpers --------------------------------------------------------

    def _provider(self, params):
        provider_id = params.get("provider", "")
        if provider_id not in registry.provider_ids():
            raise RouteError("Nguồn không tồn tại: %s" % provider_id)
        if provider_id not in self._providers:
            self._providers[provider_id] = self._create(
                provider_id, self.http, self.settings
            )
        return self._providers[provider_id]

    def _url(self, provider, params, key="url"):
        url = params.get(key, "")
        if not provider.owns_url(url):
            raise RouteError("URL không thuộc nguồn %s" % provider.name)
        return url

    def _t(self, string_id):
        return self.ui.localize(string_id)

    def _items_to_entries(self, provider, items):
        entries = []
        for item in items:
            label = item.title + (" [%s]" % item.label if item.label else "")
            entries.append(
                Entry(
                    label,
                    {
                        "action": "title",
                        "provider": provider.provider_id,
                        "url": item.url,
                    },
                    art={"poster": item.poster, "thumb": item.poster},
                    info={
                        "title": item.title,
                        "originaltitle": item.original_title,
                        "plot": item.label,
                    },
                )
            )
        return entries

    # ----- actions --------------------------------------------------------

    def _do_root(self, params):
        entries = [
            Entry(name, {"action": "provider", "provider": pid})
            for pid, name in registry.names()
        ]
        self.ui.show(entries, title=self._t(strings.SOURCES))

    def _do_provider(self, params):
        provider = self._provider(params)
        entries = []
        for section in provider.get_sections():
            if section.kind == "list":
                query = {
                    "action": "list",
                    "provider": provider.provider_id,
                    "url": section.url,
                }
            else:
                query = {"action": section.kind, "provider": provider.provider_id}
            entries.append(Entry(section.title, query))
        self.ui.show(entries, title=provider.name)

    def _do_list(self, params):
        provider = self._provider(params)
        self._show_page(provider, provider.list_titles(self._url(provider, params)))

    def _show_page(self, provider, page):
        entries = self._items_to_entries(provider, page.items)
        if not entries:
            self.ui.notify(self._t(strings.NO_RESULTS))
        if page.next_url:
            entries.append(
                Entry(
                    self._t(strings.NEXT_PAGE),
                    {
                        "action": "list",
                        "provider": provider.provider_id,
                        "url": page.next_url,
                    },
                )
            )
        self.ui.show(entries, content="tvshows", title=page.title or provider.name)

    def _do_genres(self, params):
        provider = self._provider(params)
        entries = [
            Entry(
                g.title,
                {"action": "list", "provider": provider.provider_id, "url": g.url},
            )
            for g in provider.get_genres()
        ]
        self.ui.show(entries, title=provider.name)

    def _do_search(self, params):
        provider = self._provider(params)
        query = params.get("query")
        if query is None:
            query = self.ui.prompt_text(self._t(strings.SEARCH_PROMPT))
        query = (query or "").strip()
        if not query:
            self.ui.show([], cancelled=True)
            return
        self._show_page(provider, provider.search(query))

    def _do_title(self, params):
        provider = self._provider(params)
        url = self._url(provider, params)
        details = provider.get_title(url)
        entries = []
        if details.related:
            entries.append(
                Entry(
                    self._t(strings.RELATED),
                    {"action": "related", "provider": provider.provider_id, "url": url},
                )
            )
        episodes = list(details.episodes)
        if self.settings.episode_order == "reversed":
            episodes.reverse()
        if not episodes:
            self.ui.notify(self._t(strings.NO_EPISODES))
        info = {
            "plot": details.plot,
            "genre": ", ".join(details.genres),
            "status": details.status,
            "duration": details.duration,
        }
        for episode in episodes:
            entries.append(
                Entry(
                    episode.label,
                    {
                        "action": "play",
                        "provider": provider.provider_id,
                        "url": episode.url,
                    },
                    is_folder=False,
                    playable=True,
                    art={"poster": details.item.poster, "thumb": details.item.poster},
                    info=dict(
                        info,
                        title="%s - %s" % (details.item.title, episode.label),
                        tvshowtitle=details.item.title,
                        mediatype="episode",
                    ),
                )
            )
        self.ui.show(entries, content="episodes", title=details.item.title)

    def _do_related(self, params):
        provider = self._provider(params)
        details = provider.get_title(self._url(provider, params))
        entries = [
            Entry(
                title, {"action": "title", "provider": provider.provider_id, "url": url}
            )
            for title, url in details.related
        ]
        self.ui.show(entries, title=self._t(strings.RELATED))

    def _do_options(self, params):
        provider = self._provider(params)
        url = self._url(provider, params)
        options = provider.get_playback_options(url)
        shown = playback.pick_options(
            options, self.settings.show_all_servers, self.settings.preferred_language
        )
        if len(shown) < len(options):
            self.ui.notify(self._t(strings.HIDDEN_SERVERS))
        entries = [
            Entry(
                option.label,
                {
                    "action": "play",
                    "provider": provider.provider_id,
                    "url": url,
                    "option": option.option_id,
                },
                is_folder=False,
                playable=True,
                info={"plot": option.group},
            )
            for option in shown
        ]
        self.ui.show(entries, title=provider.name)

    def _do_play(self, params):
        provider = self._provider(params)
        url = self._url(provider, params)
        wanted = params.get("option", "")
        # Re-read the page: only options the source advertises right now can play.
        options = provider.get_playback_options(url)
        if wanted:
            option = next((o for o in options if o.option_id == wanted), None)
            if option is None:
                raise RouteError("Server %s không còn trên trang tập." % wanted)
            candidates = [option]
        else:
            # One entry per episode: preferred language first, then the others.
            candidates = playback.pick_options(
                options, self.settings.show_all_servers, self.settings.preferred_language
            )
            if not candidates:
                raise RouteError("Tập này chưa có server phát được.")
        error = None
        for option in candidates:
            try:
                stream = playback.resolve_option(
                    provider, option, self.http, self.resolvers
                )
            except FamilyCinemaError as failure:
                error = failure
                continue
            self.ui.play(stream, title=option.label)
            return
        raise error
