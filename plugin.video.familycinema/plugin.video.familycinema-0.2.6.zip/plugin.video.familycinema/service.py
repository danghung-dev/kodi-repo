"""Kodi service entry point: the HLS proxy survives plugin route completion."""

import json
import os
import tempfile

from resources.lib.proxy import PlaybackProxy
from resources.lib.proxy_client import RPC_PROTOCOL, STATE_FILE


def run(profile, monitor):
    os.makedirs(profile, exist_ok=True)
    state_path = os.path.join(profile, STATE_FILE)
    proxy = PlaybackProxy().start()
    try:
        descriptor, temporary = tempfile.mkstemp(prefix=".playback-", dir=profile)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                json.dump(
                    {
                        "port": proxy.port,
                        "token": proxy.token,
                        "protocol": RPC_PROTOCOL,
                    },
                    handle,
                )
            os.replace(temporary, state_path)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
        while not monitor.waitForAbort(1):
            proxy.cleanup()
    finally:
        proxy.close()
        try:
            with open(state_path, encoding="utf-8") as handle:
                state = json.load(handle)
            # A newer service may have replaced the state during an update.
            if state.get("token") == proxy.token:
                os.unlink(state_path)
        except (OSError, ValueError, AttributeError):
            pass


if __name__ == "__main__":
    import xbmc
    import xbmcaddon
    import xbmcvfs

    run(
        xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile")), xbmc.Monitor()
    )
