"""Provider registry: add a website by registering one more class here."""
from ..errors import RouteError
from .gavang import Gavang
from .hhkungfu import HHKungfu
from .yanhh3d import YanHH3D

PROVIDER_CLASSES = (YanHH3D, HHKungfu, Gavang)


def provider_ids():
    return [cls.provider_id for cls in PROVIDER_CLASSES]


def create(provider_id, http, settings=None):
    """Instantiate a provider; ``settings`` may override ``<id>_base_url``."""
    settings = settings or {}
    for cls in PROVIDER_CLASSES:
        if cls.provider_id == provider_id:
            base_url = (settings.get('%s_base_url' % provider_id) or cls.DEFAULT_BASE_URL).strip()
            return cls(http, base_url, settings)
    raise RouteError('Nguồn không tồn tại: %s' % provider_id)


def names():
    return [(cls.provider_id, cls.name) for cls in PROVIDER_CLASSES]
