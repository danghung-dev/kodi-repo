"""KKPhim (kkphim.com): movies and series from the public phimapi.com JSON API.

kkphim.com and its mirrors are front-ends for one API; the response shapes are
captured in tests/fixtures/kkphim. A title lists one episode per episode slug
and each audio track ("server": Vietsub / Thuyết Minh / Lồng Tiếng) of that
episode is a playback option, so the preferred-language setting applies.
Streams are plain HLS playlists on the KKPhim CDN (Vietnamese IPs only).
"""

import html
import json
import re
import urllib.parse

from ..errors import ParseError
from ..models import CatalogItem, Episode, Page, PlaybackOption, Section, TitleDetails
from .base import Provider

CATALOG_TTL = 300
DETAIL_TTL = 600
GENRES_TTL = 86400
IMAGE_CDN = "https://phimimg.com"


class KKPhim(Provider):
    provider_id = "kkphim"
    name = "KKPhim"
    DEFAULT_BASE_URL = "https://phimapi.com"

    # ----- navigation -------------------------------------------------

    def get_sections(self):
        lists = self.base_url + "/v1/api/danh-sach/"
        return [
            Section("latest", "Phim mới cập nhật", "list",
                    self.base_url + "/danh-sach/phim-moi-cap-nhat?page=1"),
            Section("search", "Tìm kiếm", "search"),
            Section("genres", "Thể loại", "genres"),
            Section("series", "Phim bộ", "list", lists + "phim-bo?page=1"),
            Section("movies", "Phim lẻ", "list", lists + "phim-le?page=1"),
            Section("cartoon", "Hoạt hình", "list", lists + "hoat-hinh?page=1"),
            Section("tvshows", "TV Shows", "list", lists + "tv-shows?page=1"),
        ]

    def list_titles(self, url):
        return self.parse_list(self._get(url, CATALOG_TTL), url)

    def search(self, query):
        url = "%s/v1/api/tim-kiem?%s" % (
            self.base_url, urllib.parse.urlencode({"keyword": query, "page": 1}))
        return self.list_titles(url)

    def get_genres(self):
        return self.parse_genres(self._get(self.base_url + "/the-loai", GENRES_TTL))

    # ----- title details ----------------------------------------------

    def get_title(self, url):
        return self.parse_title(self._get(_page(url), DETAIL_TTL))

    # ----- playback options -------------------------------------------

    def get_playback_options(self, episode_url):
        wanted = urllib.parse.parse_qs(urllib.parse.urlsplit(episode_url).fragment).get("ep", [""])[0]
        # Never cached: the CDN links of an episode are replaced from time to time.
        return self.parse_options(self._get(_page(episode_url), 0), wanted)

    def get_embed_url(self, option):
        return option.source["stream"]

    # ----- fetch helper -----------------------------------------------

    def title_url(self, slug):
        return "%s/phim/%s" % (self.base_url, urllib.parse.quote(slug, safe=""))

    def _get(self, url, ttl):
        return self.http.get_text(url, allowed_hosts={self.host}, cache_ttl=ttl)

    # ----- parsers (pure; exercised by tests/test_kkphim.py) ----------

    def parse_list(self, text, page_url):
        payload = _json(text)
        # ``/danh-sach/phim-moi-cap-nhat`` answers flat; the ``/v1/api`` lists nest in ``data``.
        box = payload.get("data") if isinstance(payload.get("data"), dict) else payload
        rows = box.get("items")
        if not isinstance(rows, list):
            raise ParseError("Danh sách phim KKPhim không hợp lệ.")
        cdn = box.get("APP_DOMAIN_CDN_IMAGE") or IMAGE_CDN
        items = [self._item(row, cdn) for row in rows if isinstance(row, dict) and row.get("slug")]
        pagination = box.get("pagination") or (box.get("params") or {}).get("pagination") or {}
        current, total = _int(pagination.get("currentPage")), _int(pagination.get("totalPages"))
        next_url = _with_page(page_url, current + 1) if 0 < current < total else None
        return Page(items, next_url, str(box.get("titlePage") or ""))

    def parse_genres(self, text):
        rows = _json(text)
        if isinstance(rows, dict):
            rows = (rows.get("data") or {}).get("items")
        if not isinstance(rows, list):
            raise ParseError("Danh sách thể loại KKPhim không hợp lệ.")
        return [
            Section(row["slug"], row.get("name") or row["slug"], "list",
                    "%s/v1/api/the-loai/%s?page=1" % (self.base_url, urllib.parse.quote(row["slug"], safe="")))
            for row in rows if isinstance(row, dict) and row.get("slug")
        ]

    def parse_title(self, text):
        movie, servers = self._detail(text)
        item = self._item(movie, IMAGE_CDN)
        episodes, seen = [], set()
        # Servers may lag each other (Lồng Tiếng often has fewer episodes): take the union.
        for server in servers:
            for ep in server["episodes"]:
                if ep["slug"] in seen:
                    continue
                seen.add(ep["slug"])
                episodes.append(Episode(self.provider_id, ep["slug"], ep["name"],
                                        "%s#ep=%s" % (item.url, ep["slug"]), order=len(episodes)))
        genres = [c.get("name", "") for c in movie.get("category") or [] if isinstance(c, dict)]
        return TitleDetails(item, plot=_plot(movie), genres=[g for g in genres if g],
                            status=str(movie.get("episode_current") or ""),
                            duration=str(movie.get("time") or ""), episodes=episodes)

    def parse_options(self, text, wanted):
        _, servers = self._detail(text)
        options = []
        for index, server in enumerate(servers):
            for ep in server["episodes"]:
                if wanted and ep["slug"] != wanted:
                    continue
                options.append(PlaybackOption(
                    self.provider_id, "%d-%s" % (index, ep["slug"]),
                    "%s · %s" % (server["name"], ep["name"]), _language(server["name"]),
                    True, {"stream": ep["stream"]},
                ))
        return options

    def _detail(self, text):
        payload = _json(text)
        movie = payload.get("movie")
        if payload.get("status") is False or not isinstance(movie, dict) or not movie.get("slug"):
            raise ParseError("Phim này không còn trên KKPhim.")
        servers = []
        for server in payload.get("episodes") or []:
            if not isinstance(server, dict):
                continue
            episodes = []
            for ep in server.get("server_data") or []:
                stream = _stream(ep) if isinstance(ep, dict) else ""
                if stream and ep.get("slug"):
                    episodes.append({"slug": str(ep["slug"]), "stream": stream,
                                     "name": str(ep.get("name") or ep["slug"])})
            if episodes:
                name = str(server.get("server_name") or "").replace("#", "").strip() or "Server"
                servers.append({"name": name, "episodes": episodes})
        return movie, servers

    def _item(self, row, cdn):
        label = " · ".join(str(v) for v in (row.get("episode_current"), row.get("quality"),
                                              row.get("lang"), row.get("year")) if v)
        return CatalogItem(self.provider_id, row["slug"], self.title_url(row["slug"]),
                           str(row.get("name") or row["slug"]), str(row.get("origin_name") or ""),
                           _image(row.get("poster_url") or row.get("thumb_url"), cdn), label)


def _json(text):
    try:
        payload = json.loads(text)
    except ValueError:
        raise ParseError("API KKPhim không trả JSON; có thể đã đổi địa chỉ.")
    if not isinstance(payload, (dict, list)):
        raise ParseError("API KKPhim trả dữ liệu lạ.")
    return payload


def _page(url):
    return urllib.parse.urldefrag(url)[0]


def _with_page(url, page):
    parts = urllib.parse.urlsplit(url)
    query = [(k, v) for k, v in urllib.parse.parse_qsl(parts.query) if k != "page"]
    query.append(("page", str(page)))
    return urllib.parse.urlunsplit(parts._replace(query=urllib.parse.urlencode(query), fragment=""))


def _image(path, cdn):
    path = str(path or "").strip()
    if not path:
        return ""
    url = urllib.parse.urljoin(cdn.rstrip("/") + "/", path)
    return url if url.startswith("https://") else ""


def _is_hls(url):
    parts = urllib.parse.urlsplit(url or "")
    return parts.scheme == "https" and bool(parts.hostname) and parts.path.endswith(".m3u8") \
        and not parts.username and not parts.password


def _stream(ep):
    """``link_m3u8``, or the playlist the web player (``?url=``) would open."""
    link = str(ep.get("link_m3u8") or "").strip()
    if _is_hls(link):
        return link
    embed = urllib.parse.urlsplit(str(ep.get("link_embed") or ""))
    link = urllib.parse.parse_qs(embed.query).get("url", [""])[0]
    return link if _is_hls(link) else ""


def _language(server_name):
    lowered = server_name.lower()
    if "vietsub" in lowered:
        return "Vietsub"
    # Dubbed audio (Lồng Tiếng) serves the same viewers as voice-over (Thuyết Minh).
    if "thuyết minh" in lowered or "lồng tiếng" in lowered:
        return "Thuyết minh"
    return "Khác"


def _int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def _plot(movie):
    content = " ".join(html.unescape(re.sub(r"<[^>]+>", " ", str(movie.get("content") or ""))).split())
    meta = " · ".join(str(v) for v in (movie.get("origin_name"), movie.get("year"),
                                       movie.get("quality"), movie.get("lang")) if v)
    countries = ", ".join(c.get("name", "") for c in movie.get("country") or [] if isinstance(c, dict))
    return "\n".join(line for line in (meta, countries, content) if line)
