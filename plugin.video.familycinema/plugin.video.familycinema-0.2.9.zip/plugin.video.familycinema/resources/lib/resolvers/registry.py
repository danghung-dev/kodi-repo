from .direct_hls import DirectHlsResolver
from .streamfree import StreamfreeResolver


def default_resolvers():
    return [StreamfreeResolver(), DirectHlsResolver()]
