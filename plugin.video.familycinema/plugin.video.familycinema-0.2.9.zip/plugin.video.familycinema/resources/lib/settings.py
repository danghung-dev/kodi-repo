"""Typed add-on settings. The Kodi layer fills ``Settings.values``; tests pass a dict."""
from . import strings

LANGUAGES = ('Vietsub', 'Thuyết minh')
ORDERS = ('source', 'reversed')


class Settings(dict):
    """dict with defaults and safe accessors (Kodi stores everything as str)."""

    DEFAULTS = {
        'yanhh3d_base_url': '',
        'hhkungfu_base_url': '',
        'gavang_base_url': '',
        'kkphim_base_url': '',
        'preferred_language': 'Thuyết minh',
        'show_all_servers': False,
        'episode_order': 'source',
        'cache_enabled': True,
    }

    def __init__(self, values=None):
        super().__init__(self.DEFAULTS)
        if values:
            self.update(values)

    @property
    def preferred_language(self):
        value = self.get('preferred_language')
        return value if value in LANGUAGES else self.DEFAULTS['preferred_language']

    @property
    def show_all_servers(self):
        return _flag(self.get('show_all_servers'))

    @property
    def episode_order(self):
        value = self.get('episode_order')
        return value if value in ORDERS else ORDERS[0]

    @property
    def cache_enabled(self):
        return _flag(self.get('cache_enabled'))


def _flag(value):
    return value is True or str(value).lower() == 'true'
