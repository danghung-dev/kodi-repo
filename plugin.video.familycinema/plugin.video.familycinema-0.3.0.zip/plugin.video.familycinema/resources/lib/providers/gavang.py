"""Gavang TV (live football with Vietnamese commentators, "BLV").

The Gavang sites (gavang.io and its mirrors) are WordPress shells around one
JSON API; the response shapes are captured in tests/fixtures/gavang. A match is
a "title" and each commentator on it is an "episode", so the shared router
gives: match list → commentator → play. Streams are plain HLS (H.264/AAC).
"""

import json
import unicodedata
import urllib.parse

from ..errors import ParseError
from ..models import CatalogItem, Episode, Page, PlaybackOption, Section, TitleDetails
from .base import Provider

LIST_TTL = 60
DETAIL_TTL = 30
WEB_TYPE = "gavang"
LIVE = "live"
# The website hides the placeholder commentator that only carries ``defaultLink``.
PLACEHOLDER_BLV = "Live streaming"
FINISHED = frozenset(("finished", "ended", "ft"))


class Gavang(Provider):
    provider_id = "gavang"
    name = "Gavang TV (bóng đá)"
    DEFAULT_BASE_URL = "https://gavangtv-api.adviceme.io/api/v1"

    # ----- navigation -------------------------------------------------

    def get_sections(self):
        matches = self._matches_url()
        return [
            Section("live", "Đang trực tiếp", "list", matches + "#" + LIVE),
            Section("all", "Lịch phát sóng", "list", matches),
            Section("search", "Tìm đội bóng", "search"),
        ]

    def list_titles(self, url):
        live_only = urllib.parse.urlsplit(url).fragment == LIVE
        rows = self._rows(self._get(self._matches_url(), LIST_TTL))
        if live_only:
            rows = [row for row in rows if row.get("matchStatus") == LIVE]
        title = "Đang trực tiếp" if live_only else "Lịch phát sóng"
        return Page([self._item(row) for row in rows], None, title)

    def search(self, query):
        needle = _fold(query)
        rows = self._rows(self._get(self._matches_url(), LIST_TTL))
        found = [
            row for row in rows
            if needle in _fold(" ".join((
                _name(row, "homeTeam"), _name(row, "awayTeam"), _name(row, "competition"),
            )))
        ]
        return Page([self._item(row) for row in found], None, query)

    def get_genres(self):
        return []

    # ----- title details ----------------------------------------------

    def get_title(self, url):
        row = self.parse_detail(self._get(_page(url), DETAIL_TTL))
        item = self._item(row)
        episodes = [
            Episode(self.provider_id, blv["id"], "BLV " + blv["nickName"],
                    "%s#blv=%s" % (item.url, blv["id"]), order=index)
            for index, blv in enumerate(self._commentators(row))
        ]
        return TitleDetails(item, plot=_plot(row), genres=[_name(row, "competition")],
                            status=_status(row), episodes=episodes)

    # ----- playback options -------------------------------------------

    def get_playback_options(self, episode_url):
        wanted = urllib.parse.parse_qs(urllib.parse.urlsplit(episode_url).fragment).get("blv", [""])[0]
        # Never cached: commentators move between matches and stream ids change.
        row = self.parse_detail(self._get(_page(episode_url), 0))
        options = []
        for blv in self._commentators(row):
            if wanted and blv["id"] != wanted:
                continue
            for index, stream in enumerate(blv["streams"]):
                options.append(PlaybackOption(
                    self.provider_id, "%s-%d" % (blv["id"], index),
                    "BLV %s" % blv["nickName"], "", True, {"stream": stream},
                ))
        return options

    def get_embed_url(self, option):
        return option.source["stream"]

    # ----- fetch helper -----------------------------------------------

    def _matches_url(self):
        return "%s/matches?webType=%s" % (self.base_url, WEB_TYPE)

    def detail_url(self, slug):
        return "%s/matches/detail/%s?webType=%s" % (
            self.base_url, urllib.parse.quote(slug, safe=""), WEB_TYPE)

    def _get(self, url, ttl):
        return self.http.get_text(url, allowed_hosts={self.host}, cache_ttl=ttl)

    # ----- parsers (pure; exercised by tests/test_gavang.py) ----------

    def _rows(self, text):
        data = _data(text)
        if isinstance(data, dict):
            data = list(data.values())
        if not isinstance(data, list):
            raise ParseError("Danh sách trận Gavang không hợp lệ.")
        rows = [r for r in data if isinstance(r, dict) and r.get("slug") and _visible(r)]
        # Live first, then by kick-off time, like the website's own ordering.
        return sorted(rows, key=lambda r: (r.get("matchStatus") != LIVE, _int(r.get("matchTime"))))

    def parse_detail(self, text):
        row = _data(text)
        if not isinstance(row, dict) or not row.get("slug") or not row.get("homeTeam"):
            raise ParseError("Trận này không còn trên Gavang.")
        return row

    def _item(self, row):
        home, away = _name(row, "homeTeam"), _name(row, "awayTeam")
        live = row.get("matchStatus") == LIVE
        when = row.get("matchNormalizedDate") or ""
        title = "%s vs %s" % (home, away)
        if live:
            label = "TRỰC TIẾP %s · %s" % (_score(row), row.get("matchNormalizedTime") or "")
        else:
            label = "%s · %s" % (when, _name(row, "competition"))
        logo = (row.get("homeTeam") or {}).get("logo") or ""
        return CatalogItem(self.provider_id, row["slug"], self.detail_url(row["slug"]),
                           title, "", logo if logo.startswith("https://") else "",
                           label.strip(" ·"))

    @staticmethod
    def _commentators(row):
        found = []
        for blv in row.get("anchorAppointmentVoList") or []:
            if not isinstance(blv, dict) or blv.get("nickName") == PLACEHOLDER_BLV:
                continue
            streams = [u for u in blv.get("streamUrls") or [] if _is_hls(u)]
            if streams and blv.get("id"):
                found.append({"id": str(blv["id"]), "nickName": blv.get("nickName") or "?",
                              "streams": streams})
        return found


def _data(text):
    try:
        payload = json.loads(text)
    except ValueError:
        raise ParseError("API Gavang không trả JSON; có thể đã đổi địa chỉ.")
    if not isinstance(payload, dict) or payload.get("success") is False \
            or (payload.get("success") is not True and str(payload.get("code", "")) != "0000"):
        raise ParseError("API Gavang báo lỗi: %s" % (payload.get("message", "") if isinstance(payload, dict) else ""))
    return payload.get("data")


def _page(url):
    return urllib.parse.urldefrag(url)[0]


def _visible(row):
    if str(row.get("matchStatus", "")).lower() in FINISHED:
        return False
    blv = (row.get("anchorAppointmentVoList") or [{}])[0]
    return not (isinstance(blv, dict) and blv.get("nickName") == PLACEHOLDER_BLV)


def _is_hls(url):
    parts = urllib.parse.urlsplit(url or "")
    return parts.scheme == "https" and parts.path.endswith(".m3u8") and not parts.username


def _name(row, key):
    return str((row.get(key) or {}).get("name") or "")


def _int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def _score(row):
    home, away = row.get("homeScores") or [0], row.get("awayScores") or [0]
    return "%s-%s" % (home[0] if home else 0, away[0] if away else 0)


def _status(row):
    return "Đang đá" if row.get("matchStatus") == LIVE else "Sắp diễn ra"


def _plot(row):
    lines = [_name(row, "competition"), row.get("matchNormalizedDate") or ""]
    if row.get("matchStatus") == LIVE:
        lines.append("Tỉ số %s · %s" % (_score(row), row.get("matchNormalizedTime") or ""))
    return "\n".join(line for line in lines if line)


def _fold(text):
    text = unicodedata.normalize("NFD", str(text).lower().replace("đ", "d"))
    return "".join(ch for ch in text if not unicodedata.combining(ch))
