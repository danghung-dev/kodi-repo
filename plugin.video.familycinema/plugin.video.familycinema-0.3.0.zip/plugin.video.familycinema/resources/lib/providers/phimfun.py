"""PhimFun (phimfun.net): movies and series from server-rendered HTML pages.

Selectors come from the pages captured in tests/fixtures/phimfun. Lists are
``/the-loai/<slug>-<page>``; a title page (``/phim/...``) carries the details
and its watch page (``/xem-phim/...``) the episode list. Every episode page
offers up to two servers ("Server Gốc" and "Server bên thứ 3" via ``?sv2=true``),
each an iframe on the moviking player host (resolvers/moviking.py).
"""

import re
import urllib.parse

from .. import htmldom
from ..errors import ParseError
from ..models import CatalogItem, Episode, Page, PlaybackOption, Section, TitleDetails
from .base import Provider

CATALOG_TTL = 300
DETAIL_TTL = 600
GENRES_TTL = 86400
PAGED = re.compile(r"^(?P<stem>/(?:the-loai|quoc-gia)/[\w-]+?)-(?P<page>\d+)$")
SEO_TAIL = "Trên nền tảng PhimFun"


class PhimFun(Provider):
    provider_id = "phimfun"
    name = "PhimFun"
    DEFAULT_BASE_URL = "https://phimfun.net"

    # ----- navigation -------------------------------------------------

    def get_sections(self):
        lists = self.base_url + "/the-loai/"
        return [
            Section("latest", "Phim cập nhật", "list", lists + "phim-cap-nhat-1"),
            Section("search", "Tìm kiếm", "search"),
            Section("genres", "Thể loại & quốc gia", "genres"),
            Section("new", "Phim mới", "list", lists + "phim-moi-1"),
            Section("series", "Phim bộ", "list", lists + "phim-bo-1"),
            Section("movies", "Phim lẻ", "list", lists + "phim-le-1"),
            Section("cinema", "Phim chiếu rạp", "list", lists + "phim-chieu-rap-1"),
            Section("cartoon", "Hoạt hình", "list", lists + "hoat-hinh-1"),
            Section("vietnam", "Phim Việt Nam", "list", self.base_url + "/quoc-gia/viet-nam-1"),
        ]

    def list_titles(self, url):
        return self.parse_list(self._get(url, CATALOG_TTL), url)

    def search(self, query):
        url = "%s/search?%s" % (self.base_url, urllib.parse.urlencode({"k": query}))
        return self.list_titles(url)

    def get_genres(self):
        return self.parse_genres(self._get(self.base_url + "/", GENRES_TTL))

    # ----- title details ----------------------------------------------

    def get_title(self, url):
        details = self.parse_title(self._get(url, DETAIL_TTL), url)
        watch = self.watch_url(url)
        episodes = self.parse_episodes(self._get(watch, DETAIL_TTL), watch) if watch else []
        return TitleDetails(details.item, details.plot, details.genres, details.status,
                            episodes=episodes)

    # ----- playback options -------------------------------------------

    def get_playback_options(self, episode_url):
        # Never cached: the player ids behind a server change from time to time.
        return self.parse_options(self._get(episode_url, 0), episode_url)

    def get_embed_url(self, option):
        page = option.source["page"]
        return self.parse_embed(self._get(page, 0), page)

    # ----- fetch helper -----------------------------------------------

    def watch_url(self, title_url):
        path = urllib.parse.urlsplit(title_url).path
        if not path.startswith("/phim/"):
            return ""
        return self.base_url + "/xem-phim/" + path[len("/phim/"):].strip("/")

    def _get(self, url, ttl):
        return self.http.get_text(url, referer=self.base_url + "/",
                                  allowed_hosts={self.host}, cache_ttl=ttl)

    def _absolute(self, href, base):
        url = urllib.parse.urldefrag(urllib.parse.urljoin(base, (href or "").strip()))[0]
        return url if self.owns_url(url) else ""

    # ----- parsers (pure; exercised by tests/test_phimfun.py) ---------

    def parse_list(self, html, page_url):
        doc = htmldom.parse(html)
        items, seen = [], set()
        # The sidebars repeat cards in other MovieList boxes; the main grid is ``.Alt``.
        for box in doc.select("ul.MovieList.Alt"):
            for card in box.select("article.TPost"):
                item = self._parse_card(card, page_url)
                if item and item.url not in seen:
                    seen.add(item.url)
                    items.append(item)
        if not items and not doc.select_one("ul.MovieList.Alt"):
            raise ParseError("Trang danh sách PhimFun đã đổi cấu trúc.")
        heading = doc.select_one("main h1.Title")
        title = " ".join(heading.text().split()) if heading else ""
        return Page(items, self._next_page(doc, page_url), title)

    def _next_page(self, doc, page_url):
        match = PAGED.match(urllib.parse.urlsplit(page_url).path)
        if not match:
            return None  # search answers one page only
        wanted = "%s-%d" % (match["stem"], int(match["page"]) + 1)
        for link in doc.select(".wp-pagenavi a.page-numbers"):
            url = self._absolute(link.get("href"), page_url)
            if url and urllib.parse.urlsplit(url).path == wanted:
                return url
        return None

    def _parse_card(self, card, page_url):
        link = card.select_one("a")
        url = self._absolute(link.get("href") if link else "", page_url)
        if not url or not urllib.parse.urlsplit(url).path.startswith("/phim/"):
            return None
        name = card.select_one("h3.Title") or card.select_one(".TPMvCn .Title")
        title = " ".join(name.text().split()) if name else ""
        if not title:
            return None
        original = card.select_one(".TPMvCn p")
        image = card.select_one("img")
        poster = ""
        if image:
            poster = self._absolute(image.get("data-src") or image.get("src"), page_url)
        label = " · ".join(n.text().strip() for n in (card.select_one(".TPMvCn .Qlty"),
                                                       card.select_one(".TPMvCn .Date")) if n)
        return CatalogItem(self.provider_id, _slug(url), url, title,
                           original.text().strip() if original else "", poster, label)

    def parse_genres(self, html):
        doc = htmldom.parse(html)
        genres, seen = [], set()
        for link in doc.select("ul.sub-menu > li > a"):
            url = self._absolute(link.get("href"), self.base_url + "/")
            path = urllib.parse.urlsplit(url).path
            if not PAGED.match(path) or url in seen:
                continue
            seen.add(url)
            title = link.text().strip()
            if path.startswith("/quoc-gia/"):
                title = "Quốc gia · " + title
            genres.append(Section(_slug(url), title, "list", url))
        if not genres:
            raise ParseError("Không đọc được danh sách thể loại PhimFun.")
        return genres

    def parse_title(self, html, url):
        doc = htmldom.parse(html)
        box = doc.select_one("article.TPost.A .TPMvCn")
        heading = box.select_one("h1.Title") if box else None
        if not heading:
            raise ParseError("Trang phim PhimFun đã đổi cấu trúc.")
        subtitle = box.select_one(".SubTitle")
        meta = doc.select_one('meta[property="og:image"]')
        poster = self._absolute(meta.get("content"), url) if meta else ""
        info = [n.text().strip() for n in box.select(".Info .Date")]
        info += [n.text().strip() for n in box.select(".Info .Qlty")]
        item = CatalogItem(self.provider_id, _slug(url), url, heading.text().strip(),
                           subtitle.text().strip() if subtitle else "", poster,
                           " · ".join(v for v in info if v))
        description = box.select_one(".Description p")
        plot = _clean(description.text()) if description else ""
        plot = plot.split(SEO_TAIL, 1)[0].strip()
        genres = [a.text().strip() for a in box.select("p.Genre.phayCuoiCau a")]
        return TitleDetails(item, plot="\n".join(v for v in (item.label, plot) if v),
                            genres=[g for g in genres if g], status=item.label)

    def parse_episodes(self, html, page_url):
        episodes = []
        for link in self._block(htmldom.parse(html), "Danh sách tập"):
            url = self._absolute(link.get("href"), page_url)
            if not url:
                continue
            label = link.text().strip() or link.get("title", "").strip()
            episodes.append(Episode(self.provider_id, _slug(url), label, url,
                                    order=len(episodes)))
        return episodes

    def parse_options(self, html, episode_url):
        doc = htmldom.parse(html)
        options = []
        for link in self._block(doc, "Danh sách máy chủ"):
            url = self._absolute(link.get("href"), episode_url)
            if not url:
                continue
            third = "sv2=true" in urllib.parse.urlsplit(url).query
            options.append(PlaybackOption(
                self.provider_id, "sv2" if third else "goc",
                link.text().strip() or ("Server bên thứ 3" if third else "Server Gốc"),
                "Vietsub", True, {"page": url, "referer": self.base_url + "/"},
            ))
        if not options and doc.select_one("iframe#iframeStream"):
            options.append(PlaybackOption(self.provider_id, "goc", "Server Gốc", "Vietsub",
                                          True, {"page": episode_url,
                                                 "referer": self.base_url + "/"}))
        return options

    def parse_embed(self, html, page_url):
        frame = htmldom.parse(html).select_one("iframe#iframeStream")
        src = urllib.parse.urljoin(page_url, (frame.get("src") or "").strip()) if frame else ""
        parts = urllib.parse.urlsplit(src)
        if parts.scheme != "https" or not parts.hostname or parts.username or parts.password:
            raise ParseError("Tập này chưa có trình phát trên PhimFun.")
        return src

    @staticmethod
    def _block(doc, heading):
        """Links of the ``section.SeasonBx`` whose title is ``heading``."""
        for section in doc.select("section.SeasonBx"):
            title = section.select_one(".Title")
            if title and title.text().strip() == heading:
                return section.select("ul.halim-list-eps a")
        return []


def _slug(url):
    return urllib.parse.urlsplit(url).path.strip("/").rsplit("/", 1)[-1]


def _clean(text):
    # Descriptions are double-escaped: "&amp;nbsp;" reaches us as a literal "&nbsp;".
    return " ".join(text.replace("&nbsp;", " ").split())
