"""Plain HLS playlists that Kodi can open as-is (no player page, no decryption)."""

import urllib.parse

from ..http_client import USER_AGENT
from ..models import ResolvedStream
from .base import Resolver


class DirectHlsResolver(Resolver):
    name = 'direct-hls'

    def can_handle(self, embed_url):
        parts = urllib.parse.urlsplit(embed_url or '')
        return parts.scheme == 'https' and bool(parts.hostname) and not parts.username \
            and not parts.password and parts.path.endswith('.m3u8')

    def resolve(self, embed_url, referer, http):
        headers = {'User-Agent': USER_AGENT}
        if referer:
            headers['Referer'] = referer
        return ResolvedStream(embed_url, headers, 'application/vnd.apple.mpegurl', 'hls')
