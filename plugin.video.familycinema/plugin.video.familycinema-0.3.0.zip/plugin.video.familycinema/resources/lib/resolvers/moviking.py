"""Moviking player pages (``moviking.<domain>/embed?id=...``) used by PhimFun.

The player host refuses foreign IPs, so its page could not be captured for
tests; this resolver looks for the HLS playlist the way the player would load
it: an absolute or relative ``.m3u8`` URL in the page (JSON-escaped or not),
or one nested player iframe holding it. Unverified until tried from Vietnam.
"""

import html
import re
import urllib.parse

from ..errors import ResolverUnavailable
from ..http_client import USER_AGENT
from ..models import ResolvedStream
from .base import Resolver

PLAYLIST = re.compile(r"""(?:https?:)?(?:\\?/){2}[^\s"'<>()]+?\.m3u8(?:\?[^\s"'<>()]*)?""")
RELATIVE = re.compile(r"""["'](/[^\s"'<>()]+?\.m3u8(?:\?[^\s"'<>()]*)?)["']""")
IFRAME = re.compile(r"""<iframe[^>]+src=["']([^"']+)["']""", re.I)


class MovikingResolver(Resolver):
    name = "moviking"

    def can_handle(self, embed_url):
        parts = urllib.parse.urlsplit(embed_url or "")
        return parts.scheme == "https" and (parts.hostname or "").lower().startswith("moviking.") \
            and not parts.username and not parts.password

    def resolve(self, embed_url, referer, http):
        # The player may hand off to a CDN host of its own; HttpClient still enforces HTTPS.
        page = http.get_text(embed_url, referer=referer)
        stream = find_playlist(page, embed_url)
        player = embed_url
        if not stream:
            frame = IFRAME.search(page)
            nested = urllib.parse.urljoin(embed_url, html.unescape(frame.group(1))) if frame else ""
            if _https(nested):
                page = http.get_text(nested, referer=embed_url)
                stream, player = find_playlist(page, nested), nested
        if not stream:
            raise ResolverUnavailable(
                "PhimFun: trình phát không trả link phát (máy chủ có thể chỉ mở cho mạng Việt Nam).")
        origin = "%s://%s" % urllib.parse.urlsplit(player)[:2]
        headers = {"User-Agent": USER_AGENT, "Referer": origin + "/", "Origin": origin}
        return ResolvedStream(stream, headers, "application/vnd.apple.mpegurl", "hls")


def find_playlist(page, base):
    """First https ``.m3u8`` URL in ``page``, resolved against ``base``."""
    for match in PLAYLIST.finditer(page):
        url = html.unescape(match.group(0).replace("\\/", "/"))
        url = urllib.parse.urljoin(base, url)
        if _https(url):
            return url
    match = RELATIVE.search(page)
    if match:
        url = urllib.parse.urljoin(base, html.unescape(match.group(1)))
        if _https(url):
            return url
    return ""


def _https(url):
    parts = urllib.parse.urlsplit(url or "")
    return parts.scheme == "https" and bool(parts.hostname) and not parts.username \
        and not parts.password
