from .direct_hls import DirectHlsResolver
from .moviking import MovikingResolver
from .streamfree import StreamfreeResolver


def default_resolvers():
    return [StreamfreeResolver(), MovikingResolver(), DirectHlsResolver()]
