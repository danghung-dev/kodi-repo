"""String ids shared with resources/language/*/strings.po (tests keep them in sync)."""

ADDON_NAME = 30000
SEARCH_PROMPT = 30010
NEXT_PAGE = 30011
RELATED = 30012
NO_RESULTS = 30013
ERROR_TITLE = 30014
HIDDEN_SERVERS = 30015
NO_EPISODES = 30016
SOURCES = 30017

SETTING_BASE_URL = 30100
SETTING_LANGUAGE = 30101
SETTING_SHOW_ALL = 30102
SETTING_ORDER = 30103
SETTING_CACHE = 30104
SETTING_CATEGORY = 30105
SETTING_HHKUNGFU_URL = 30106
SETTING_GAVANG_URL = 30107
SETTING_KKPHIM_URL = 30108
SETTING_PHIMFUN_URL = 30109
ORDER_SOURCE = 30110
ORDER_REVERSED = 30111
LANG_VIETSUB = 30112
LANG_DUBBED = 30113

DEFAULTS = {
    ADDON_NAME: 'Family Cinema',
    SEARCH_PROMPT: 'Tìm phim',
    NEXT_PAGE: 'Trang tiếp »',
    RELATED: 'Phần liên quan',
    NO_RESULTS: 'Không tìm thấy phim nào.',
    ERROR_TITLE: 'Family Cinema',
    HIDDEN_SERVERS: 'Còn server khác chưa xác minh; bật "Hiện mọi server" trong cài đặt để xem.',
    NO_EPISODES: 'Phim chưa có tập nào.',
    SOURCES: 'Nguồn phim',
    SETTING_BASE_URL: 'Địa chỉ YanHH3D (đổi domain cần kiểm tra lại)',
    SETTING_HHKUNGFU_URL: 'Địa chỉ HHKUNGFU (đổi domain cần kiểm tra lại)',
    SETTING_GAVANG_URL: 'Địa chỉ API Gavang TV (bóng đá trực tiếp)',
    SETTING_KKPHIM_URL: 'Địa chỉ API KKPhim (phimapi.com)',
    SETTING_PHIMFUN_URL: 'Địa chỉ PhimFun (đổi domain cần kiểm tra lại)',
    SETTING_LANGUAGE: 'Ngôn ngữ ưu tiên',
    SETTING_SHOW_ALL: 'Hiện mọi server (chưa xác minh)',
    SETTING_ORDER: 'Thứ tự tập',
    SETTING_CACHE: 'Lưu đệm trang danh sách',
    SETTING_CATEGORY: 'Chung',
    ORDER_SOURCE: 'Như website (mới nhất trước)',
    ORDER_REVERSED: 'Đảo ngược (tập 1 trước)',
    LANG_VIETSUB: 'Vietsub',
    LANG_DUBBED: 'Thuyết minh',
}
