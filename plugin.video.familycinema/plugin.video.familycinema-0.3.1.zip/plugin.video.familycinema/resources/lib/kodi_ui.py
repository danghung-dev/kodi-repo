"""Kodi adapter: Entry/ResolvedStream → ListItem, notifications and playback.

Only this module (and addon.py) imports xbmc*, so everything else runs and is
tested outside Kodi.
"""
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from . import strings
from .router import build_query
from .settings import Settings

ADDON = xbmcaddon.Addon()
PLUGIN_URL = 'plugin://%s/' % ADDON.getAddonInfo('id')


def load_settings():
    return Settings({
        'yanhh3d_base_url': ADDON.getSetting('yanhh3d_base_url'),
        'hhkungfu_base_url': ADDON.getSetting('hhkungfu_base_url'),
        'gavang_base_url': ADDON.getSetting('gavang_base_url'),
        'kkphim_base_url': ADDON.getSetting('kkphim_base_url'),
        'phimfun_base_url': ADDON.getSetting('phimfun_base_url'),
        'socolive_base_url': ADDON.getSetting('socolive_base_url'),
        'preferred_language': ADDON.getSetting('preferred_language'),
        'show_all_servers': ADDON.getSetting('show_all_servers'),
        'episode_order': ADDON.getSetting('episode_order'),
        'cache_enabled': ADDON.getSetting('cache_enabled'),
    })


def profile_dir():
    from xbmcvfs import translatePath
    return translatePath(ADDON.getAddonInfo('profile'))


class KodiUI:
    def __init__(self, handle):
        self.handle = handle

    def localize(self, string_id):
        text = ADDON.getLocalizedString(string_id)
        return text or strings.DEFAULTS.get(string_id, '')

    def notify(self, message, error=False):
        icon = xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO
        xbmcgui.Dialog().notification(self.localize(strings.ERROR_TITLE), message, icon, 6000)

    def prompt_text(self, heading):
        keyboard = xbmc.Keyboard('', heading)
        keyboard.doModal()
        return keyboard.getText() if keyboard.isConfirmed() else ''

    def show(self, entries, content='videos', title='', cancelled=False):
        if cancelled:
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return
        if title:
            xbmcplugin.setPluginCategory(self.handle, title)
        xbmcplugin.setContent(self.handle, content)
        for entry in entries:
            item = xbmcgui.ListItem(label=entry.label)
            if entry.art:
                item.setArt({k: v for k, v in entry.art.items() if v})
            tag = item.getVideoInfoTag()
            if entry.info.get('plot'):
                tag.setPlot(entry.info['plot'])
            if entry.info.get('title'):
                tag.setTitle(entry.info['title'])
            if entry.info.get('originaltitle'):
                tag.setOriginalTitle(entry.info['originaltitle'])
            if entry.info.get('tvshowtitle'):
                tag.setTvShowTitle(entry.info['tvshowtitle'])
            if entry.info.get('mediatype'):
                tag.setMediaType(entry.info['mediatype'])
            if entry.playable:
                item.setProperty('IsPlayable', 'true')
            url = PLUGIN_URL + '?' + build_query(entry.params)
            xbmcplugin.addDirectoryItem(self.handle, url, item, entry.is_folder)
        xbmcplugin.endOfDirectory(self.handle)

    def play(self, stream, title=''):
        url = stream.url
        if stream.headers:
            url += '|' + urllib.parse.urlencode(stream.headers)
        item = xbmcgui.ListItem(label=title, path=url)
        if stream.mime:
            item.setMimeType(stream.mime)
            item.setContentLookup(False)
        # Our loopback relay already serves clear MPEG-TS HLS; Kodi's native
        # player can handle it without an installed InputStream Adaptive add-on.
        if stream.inputstream or (stream.protocol == 'hls' and urllib.parse.urlsplit(stream.url).hostname != '127.0.0.1'):
            item.setProperty('inputstream', stream.inputstream or 'inputstream.adaptive')
            item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        if stream.subtitles:
            item.setSubtitles(stream.subtitles)
        xbmcplugin.setResolvedUrl(self.handle, True, item)

    def play_failed(self):
        xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
