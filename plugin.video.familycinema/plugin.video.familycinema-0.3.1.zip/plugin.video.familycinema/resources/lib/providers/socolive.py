"""Socolive (live football with Vietnamese commentators, "BLV").

The Socolive sites (socolive39.co and its mirrors, also some Cakhia-branded
ones) are WordPress shells around the "VSC" JSON API; the response shapes are
captured in tests/fixtures/socolive. The match list only answers a POST with a
date range; one match is a plain GET by id. As with Gavang, a match is a
"title" and each commentator is an "episode". Streams are plain HLS.
"""

import datetime
import json
import time
import unicodedata
import urllib.parse

from ..errors import ParseError
from ..models import CatalogItem, Episode, Page, PlaybackOption, Section, TitleDetails
from .base import Provider

LIST_TTL = 60
DETAIL_TTL = 30
LIVE = "live"
VN = datetime.timezone(datetime.timedelta(hours=7))
NOT_STARTED = frozenset(("not started", "to be determined", "delay", "delayed"))
FINISHED = frozenset(("finished", "ended", "postponed", "cancelled", "canceled",
                      "abandoned", "interrupted", "suspended"))
PERIODS = {"first half": "Hiệp 1", "second half": "Hiệp 2", "half time": "Nghỉ giữa hiệp",
           "halftime": "Nghỉ giữa hiệp", "extra time": "Hiệp phụ", "penalty": "Luân lưu",
           "penalties": "Luân lưu"}
# A match the API still calls "not started" this long after kick-off is stale.
STALE_AFTER = 3 * 3600
# The plain broadcast feed, without a commentator.
HOUSE_FEED = "Nhà Đài"


class Socolive(Provider):
    provider_id = "socolive"
    name = "Socolive (bóng đá)"
    DEFAULT_BASE_URL = "https://vsc-apidev.helizones.com/api/data"

    def __init__(self, http, base_url, settings=None, now=time.time):
        super().__init__(http, base_url, settings)
        self.now = now

    # ----- navigation -------------------------------------------------

    def get_sections(self):
        matches = self._matches_url()
        return [
            Section("live", "Đang trực tiếp", "list", matches + "#" + LIVE),
            Section("all", "Lịch phát sóng", "list", matches),
            Section("search", "Tìm đội bóng", "search"),
        ]

    def list_titles(self, url):
        live_only = urllib.parse.urlsplit(url).fragment == LIVE
        rows = self._fetch_rows()
        if live_only:
            rows = [row for row in rows if _is_live(row)]
        title = "Đang trực tiếp" if live_only else "Lịch phát sóng"
        return Page([self._item(row) for row in rows], None, title)

    def search(self, query):
        needle = _fold(query)
        found = [
            row for row in self._fetch_rows()
            if needle in _fold(" ".join((
                _team(row, "home"), _team(row, "away"), _league(row),
            )))
        ]
        return Page([self._item(row) for row in found], None, query)

    def get_genres(self):
        return []

    # ----- title details ----------------------------------------------

    def get_title(self, url):
        row = self.parse_detail(self._get(_page(url), DETAIL_TTL))
        item = self._item(row)
        episodes = [
            Episode(self.provider_id, link["id"], link["label"],
                    "%s#live=%s" % (item.url, link["id"]), order=index)
            for index, link in enumerate(_links(row))
        ]
        return TitleDetails(item, plot=_plot(row), genres=[_league(row)],
                            status="Đang đá" if _is_live(row) else "Sắp diễn ra",
                            episodes=episodes)

    # ----- playback options -------------------------------------------

    def get_playback_options(self, episode_url):
        wanted = urllib.parse.parse_qs(urllib.parse.urlsplit(episode_url).fragment).get("live", [""])[0]
        # Never cached: commentators move between matches and stream ids change.
        row = self.parse_detail(self._get(_page(episode_url), 0))
        return [
            PlaybackOption(self.provider_id, link["id"], link["label"], "", True,
                           {"stream": link["stream"]})
            for link in _links(row) if not wanted or link["id"] == wanted
        ]

    def get_embed_url(self, option):
        return option.source["stream"]

    # ----- fetch helpers ----------------------------------------------

    def _matches_url(self):
        return self.base_url + "/lives/range-date"

    def detail_url(self, match_id):
        return "%s/lives/%s" % (self.base_url, urllib.parse.quote(match_id, safe=""))

    def _get(self, url, ttl):
        return self.http.get_text(url, allowed_hosts={self.host}, cache_ttl=ttl)

    def _fetch_rows(self):
        today = datetime.datetime.fromtimestamp(self.now(), VN).date()
        # From yesterday: a late kick-off is still live after midnight.
        payload = {"fromDate": (today - datetime.timedelta(days=1)).isoformat(),
                   "toDate": (today + datetime.timedelta(days=1)).isoformat()}
        text = self.http.post_json(self._matches_url(), payload,
                                   allowed_hosts={self.host}, cache_ttl=LIST_TTL)
        return self.parse_rows(text)

    # ----- parsers (pure; exercised by tests/test_socolive.py) --------

    def parse_rows(self, text):
        payload = _json(text)
        days = payload.get("matches_by_date")
        if not isinstance(days, dict):
            raise ParseError("Danh sách trận Socolive không hợp lệ.")
        now = self.now()
        rows, seen = [], set()
        for day in days.values():
            for row in day if isinstance(day, list) else []:
                if not isinstance(row, dict) or not _match_id(row) or _match_id(row) in seen:
                    continue
                seen.add(_match_id(row))
                if _visible(row, now):
                    rows.append(row)
        # Live first, then by kick-off time.
        return sorted(rows, key=lambda r: (not _is_live(r), _kickoff(r) or 0))

    def parse_detail(self, text):
        row = _json(text).get("data")
        if not isinstance(row, dict) or not _match_id(row) or not (row.get("teams") or {}).get("home"):
            raise ParseError("Trận này không còn trên Socolive.")
        return row

    def _item(self, row):
        title = "%s vs %s" % (_team(row, "home"), _team(row, "away"))
        if _is_live(row):
            label = "TRỰC TIẾP %s · %s" % (_score(row), _period(row))
        else:
            label = "%s · %s" % (_when(row), _league(row))
        logo = ((row.get("teams") or {}).get("home") or {}).get("logo") or ""
        match_id = _match_id(row)
        return CatalogItem(self.provider_id, match_id, self.detail_url(match_id), title, "",
                           logo if logo.startswith("https://") else "", label.strip(" ·"))


def _json(text):
    try:
        payload = json.loads(text)
    except ValueError:
        raise ParseError("API Socolive không trả JSON; có thể đã đổi địa chỉ.")
    if not isinstance(payload, dict):
        raise ParseError("API Socolive trả dữ liệu lạ.")
    return payload


def _page(url):
    return urllib.parse.urldefrag(url)[0]


def _match_id(row):
    return str(row.get("match_id") or row.get("matchId") or "")


def _status(row):
    # The list puts ``status`` on the match; the detail nests it in ``matchInfo``.
    status = row.get("status")
    if not isinstance(status, str):
        status = (row.get("matchInfo") or {}).get("status")
    return str(status or "").strip().lower()


def _is_live(row):
    status = _status(row)
    return bool(status) and status not in NOT_STARTED and status not in FINISHED


def _kickoff(row):
    value = row.get("kickoff") or (row.get("matchInfo") or {}).get("kickoff") or ""
    try:
        moment = datetime.datetime.fromisoformat(str(value))
    except ValueError:
        return None
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=VN)
    return moment.timestamp()


def _visible(row, now):
    status = _status(row)
    if status in FINISHED or not _links(row):
        return False
    kickoff = _kickoff(row)
    return not (status in NOT_STARTED and kickoff and kickoff < now - STALE_AFTER)


def _links(row):
    """Playable commentator feeds; the "18+" promo link has no stream URL."""
    found = []
    for link in (row.get("livestream") or {}).get("links") or []:
        if not isinstance(link, dict) or not _is_hls(link.get("url")):
            continue
        name = str(link.get("commentator") or "?").strip()
        link_id = str(link.get("liveId") or link.get("commentatorId") or "")
        if link_id and link_id not in [f["id"] for f in found]:
            found.append({"id": link_id, "stream": link["url"],
                          "label": name if name == HOUSE_FEED else "BLV " + name})
    return found


def _is_hls(url):
    parts = urllib.parse.urlsplit(url or "")
    return parts.scheme == "https" and parts.path.endswith(".m3u8") \
        and not parts.username and not parts.password


def _team(row, side):
    return str((((row.get("teams") or {}).get(side)) or {}).get("name") or "")


def _league(row):
    return str((row.get("league") or {}).get("name") or "")


def _score(row):
    full = (row.get("score") or {}).get("fulltime") or {}
    return "%s-%s" % (full.get("home") or 0, full.get("away") or 0)


def _period(row):
    minute = row.get("currentMinutes")
    period = PERIODS.get(_status(row), "")
    if minute:
        return ("%s: %s'" % (period, minute)) if period else "%s'" % minute
    return period


def _when(row):
    kickoff = _kickoff(row)
    if kickoff is None:
        return ""
    return datetime.datetime.fromtimestamp(kickoff, VN).strftime("%H:%M %d/%m")


def _plot(row):
    lines = [_league(row), _when(row)]
    if _is_live(row):
        lines.append("Tỉ số %s · %s" % (_score(row), _period(row)))
    return "\n".join(line.strip(" ·") for line in lines if line)


def _fold(text):
    text = unicodedata.normalize("NFD", str(text).lower().replace("đ", "d"))
    return "".join(ch for ch in text if not unicodedata.combining(ch))
